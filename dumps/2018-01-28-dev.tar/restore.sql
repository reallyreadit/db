--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.6
-- Dumped by pg_dump version 9.6.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = core, pg_catalog;

ALTER TABLE ONLY core.user_page DROP CONSTRAINT user_page_user_account_id_fkey;
ALTER TABLE ONLY core.user_page DROP CONSTRAINT user_page_page_id_fkey;
ALTER TABLE ONLY core.star DROP CONSTRAINT star_user_account_id_fkey;
ALTER TABLE ONLY core.star DROP CONSTRAINT star_article_id_fkey;
ALTER TABLE ONLY core.password_reset_request DROP CONSTRAINT password_reset_request_user_account_id_fkey;
ALTER TABLE ONLY core.page DROP CONSTRAINT page_article_id_fkey;
ALTER TABLE ONLY core.email_confirmation DROP CONSTRAINT email_confirmation_user_account_id_fkey;
ALTER TABLE ONLY core.email_bounce DROP CONSTRAINT email_bounce_bulk_mailing_id_fkey;
ALTER TABLE ONLY core.comment DROP CONSTRAINT comment_user_account_id_fkey;
ALTER TABLE ONLY core.comment DROP CONSTRAINT comment_parent_comment_id_fkey;
ALTER TABLE ONLY core.comment DROP CONSTRAINT comment_article_id_fkey;
ALTER TABLE ONLY core.bulk_mailing DROP CONSTRAINT bulk_mailing_user_account_id_fkey;
ALTER TABLE ONLY core.bulk_mailing_recipient DROP CONSTRAINT bulk_mailing_recipient_user_account_id_fkey;
ALTER TABLE ONLY core.bulk_mailing_recipient DROP CONSTRAINT bulk_mailing_recipient_bulk_mailing_id_fkey;
ALTER TABLE ONLY core.article_tag DROP CONSTRAINT article_tag_tag_id_fkey;
ALTER TABLE ONLY core.article_tag DROP CONSTRAINT article_tag_article_id_fkey;
ALTER TABLE ONLY core.article DROP CONSTRAINT article_source_id_fkey;
ALTER TABLE ONLY core.article_author DROP CONSTRAINT article_author_author_id_fkey;
ALTER TABLE ONLY core.article_author DROP CONSTRAINT article_author_article_id_fkey;
SET search_path = article_api, pg_catalog;

DROP RULE "_RETURN" ON article_api.article;
SET search_path = core, pg_catalog;

DROP INDEX core.user_account_name_key;
DROP INDEX core.user_account_email_key;
ALTER TABLE ONLY core.user_page DROP CONSTRAINT user_page_pkey;
ALTER TABLE ONLY core.user_account DROP CONSTRAINT user_account_pkey;
ALTER TABLE ONLY core.tag DROP CONSTRAINT tag_pkey;
ALTER TABLE ONLY core.tag DROP CONSTRAINT tag_name_key;
ALTER TABLE ONLY core.star DROP CONSTRAINT star_pkey;
ALTER TABLE ONLY core.source DROP CONSTRAINT source_slug_key;
ALTER TABLE ONLY core.source_rule DROP CONSTRAINT source_rule_pkey;
ALTER TABLE ONLY core.source DROP CONSTRAINT source_pkey;
ALTER TABLE ONLY core.source DROP CONSTRAINT source_hostname_key;
ALTER TABLE ONLY core.password_reset_request DROP CONSTRAINT password_reset_request_pkey;
ALTER TABLE ONLY core.page DROP CONSTRAINT page_pkey;
ALTER TABLE ONLY core.email_confirmation DROP CONSTRAINT email_confirmation_pkey;
ALTER TABLE ONLY core.email_bounce DROP CONSTRAINT email_bounce_pkey;
ALTER TABLE ONLY core.comment DROP CONSTRAINT comment_pkey;
ALTER TABLE ONLY core.bulk_mailing_recipient DROP CONSTRAINT bulk_mailing_recipient_pkey;
ALTER TABLE ONLY core.bulk_mailing DROP CONSTRAINT bulk_mailing_pkey;
ALTER TABLE ONLY core.author DROP CONSTRAINT author_pkey;
ALTER TABLE ONLY core.article_tag DROP CONSTRAINT article_tag_pkey;
ALTER TABLE ONLY core.article DROP CONSTRAINT article_slug_key;
ALTER TABLE ONLY core.article DROP CONSTRAINT article_pkey;
ALTER TABLE ONLY core.article_author DROP CONSTRAINT article_author_pkey;
DROP TABLE core.tag;
DROP TABLE core.bulk_mailing_recipient;
DROP TABLE core.bulk_mailing;
DROP TABLE core.author;
DROP TABLE core.article_tag;
DROP TABLE core.article_author;
SET search_path = article_api, pg_catalog;

DROP VIEW article_api.article_score;
DROP VIEW article_api.user_article_read;
SET search_path = user_account_api, pg_catalog;

DROP FUNCTION user_account_api.update_notification_preferences(user_account_id uuid, receive_reply_email_notifications boolean, receive_reply_desktop_notifications boolean);
DROP FUNCTION user_account_api.update_contact_preferences(user_account_id uuid, receive_website_updates boolean, receive_suggested_readings boolean);
DROP FUNCTION user_account_api.record_new_reply_desktop_notification(user_account_id uuid);
DROP FUNCTION user_account_api.list_user_accounts();
DROP FUNCTION user_account_api.is_email_address_confirmed(user_account_id uuid, email text);
DROP FUNCTION user_account_api.get_user_account(user_account_id uuid);
DROP FUNCTION user_account_api.get_password_reset_request(password_reset_request_id uuid);
DROP FUNCTION user_account_api.get_latest_unread_reply(user_account_id uuid);
DROP FUNCTION user_account_api.get_latest_unconfirmed_email_confirmation(user_account_id uuid);
DROP FUNCTION user_account_api.get_latest_password_reset_request(user_account_id uuid);
DROP FUNCTION user_account_api.get_email_confirmation(email_confirmation_id uuid);
DROP FUNCTION user_account_api.find_user_account(email text);
DROP FUNCTION user_account_api.create_user_account(name text, email text, password_hash bytea, password_salt bytea);
DROP VIEW user_account_api.user_account;
DROP FUNCTION user_account_api.create_password_reset_request(user_account_id uuid);
SET search_path = core, pg_catalog;

DROP TABLE core.password_reset_request;
SET search_path = user_account_api, pg_catalog;

DROP FUNCTION user_account_api.create_email_confirmation(user_account_id uuid);
SET search_path = core, pg_catalog;

DROP TABLE core.email_confirmation;
SET search_path = user_account_api, pg_catalog;

DROP FUNCTION user_account_api.confirm_email_address(email_confirmation_id uuid);
DROP FUNCTION user_account_api.complete_password_reset_request(password_reset_request_id uuid);
DROP FUNCTION user_account_api.change_password(user_account_id uuid, password_hash bytea, password_salt bytea);
DROP FUNCTION user_account_api.change_email_address(user_account_id uuid, email text);
DROP FUNCTION user_account_api.ack_new_reply(user_account_id uuid);
SET search_path = bulk_mailing_api, pg_catalog;

DROP FUNCTION bulk_mailing_api.list_email_bounces();
SET search_path = core, pg_catalog;

DROP TABLE core.email_bounce;
SET search_path = bulk_mailing_api, pg_catalog;

DROP FUNCTION bulk_mailing_api.list_bulk_mailings();
DROP FUNCTION bulk_mailing_api.create_bulk_mailing(subject text, body text, list text, user_account_id uuid, recipients create_bulk_mailing_recipient[]);
SET search_path = article_api, pg_catalog;

DROP FUNCTION article_api.update_user_page(user_page_id uuid, read_state integer[]);
DROP FUNCTION article_api.unstar_article(user_account_id uuid, article_id uuid);
DROP FUNCTION article_api.star_article(user_account_id uuid, article_id uuid);
DROP FUNCTION article_api.set_aotd();
DROP FUNCTION article_api.score_articles();
DROP FUNCTION article_api.read_comment(comment_id uuid);
DROP FUNCTION article_api.list_user_hot_topics(user_account_id uuid, page_number integer, page_size integer);
DROP FUNCTION article_api.list_user_article_history(user_account_id uuid, page_number integer, page_size integer);
DROP FUNCTION article_api.list_starred_articles(user_account_id uuid, page_number integer, page_size integer);
DROP FUNCTION article_api.list_replies(user_account_id uuid, page_number integer, page_size integer);
DROP FUNCTION article_api.list_hot_topics(page_number integer, page_size integer);
DROP FUNCTION article_api.list_comments(article_id uuid);
DROP FUNCTION article_api.get_user_page(page_id uuid, user_account_id uuid);
DROP FUNCTION article_api.get_user_article(article_id uuid, user_account_id uuid);
DROP FUNCTION article_api.get_user_aotd(user_account_id uuid);
DROP FUNCTION article_api.get_source_rules();
SET search_path = core, pg_catalog;

DROP TABLE core.source_rule;
SET search_path = article_api, pg_catalog;

DROP FUNCTION article_api.get_page(page_id uuid);
DROP FUNCTION article_api.get_comment(comment_id uuid);
DROP FUNCTION article_api.get_aotd();
DROP FUNCTION article_api.find_user_article(slug text, user_account_id uuid);
DROP VIEW article_api.user_article;
SET search_path = core, pg_catalog;

DROP TABLE core.star;
SET search_path = article_api, pg_catalog;

DROP VIEW article_api.user_article_progress;
DROP VIEW article_api.article_pages;
DROP FUNCTION article_api.find_source(source_hostname text);
DROP FUNCTION article_api.find_page(url text);
DROP FUNCTION article_api.find_article(slug text);
DROP TABLE article_api.article;
DROP FUNCTION article_api.delete_user_article(article_id uuid, user_account_id uuid);
DROP FUNCTION article_api.delete_article(id uuid);
DROP FUNCTION article_api.create_user_page(page_id uuid, user_account_id uuid);
SET search_path = core, pg_catalog;

DROP TABLE core.user_page;
SET search_path = article_api, pg_catalog;

DROP FUNCTION article_api.create_source(name text, url text, hostname text, slug text);
SET search_path = core, pg_catalog;

DROP TABLE core.source;
SET search_path = article_api, pg_catalog;

DROP FUNCTION article_api.create_page(article_id uuid, number integer, word_count integer, readable_word_count integer, url text);
SET search_path = core, pg_catalog;

DROP TABLE core.page;
SET search_path = article_api, pg_catalog;

DROP FUNCTION article_api.create_comment(text text, article_id uuid, parent_comment_id uuid, user_account_id uuid);
DROP VIEW article_api.user_comment;
SET search_path = core, pg_catalog;

DROP TABLE core.user_account;
DROP TABLE core.comment;
DROP TABLE core.article;
DROP FUNCTION core.utc_now();
SET search_path = article_api, pg_catalog;

DROP FUNCTION article_api.create_article(title text, slug text, source_id uuid, date_published timestamp without time zone, date_modified timestamp without time zone, section text, description text, authors create_article_author[], tags text[]);
SET search_path = core, pg_catalog;

DROP TYPE core.user_account_role;
DROP TYPE core.source_rule_action;
SET search_path = bulk_mailing_api, pg_catalog;

DROP TYPE bulk_mailing_api.create_bulk_mailing_recipient;
SET search_path = article_api, pg_catalog;

DROP TYPE article_api.user_comment_page_result;
DROP TYPE article_api.user_article_page_result;
DROP TYPE article_api.create_article_author;
DROP TYPE article_api.article_page_result;
DROP EXTENSION pgcrypto;
DROP EXTENSION plpgsql;
DROP SCHEMA user_account_api;
DROP SCHEMA pgcrypto;
DROP SCHEMA core;
DROP SCHEMA bulk_mailing_api;
DROP SCHEMA article_api;
--
-- Name: article_api; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA article_api;


ALTER SCHEMA article_api OWNER TO postgres;

--
-- Name: bulk_mailing_api; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA bulk_mailing_api;


ALTER SCHEMA bulk_mailing_api OWNER TO postgres;

--
-- Name: core; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA core;


ALTER SCHEMA core OWNER TO postgres;

--
-- Name: pgcrypto; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA pgcrypto;


ALTER SCHEMA pgcrypto OWNER TO postgres;

--
-- Name: user_account_api; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA user_account_api;


ALTER SCHEMA user_account_api OWNER TO postgres;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA pgcrypto;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET search_path = article_api, pg_catalog;

--
-- Name: article_page_result; Type: TYPE; Schema: article_api; Owner: postgres
--

CREATE TYPE article_page_result AS (
	id uuid,
	title text,
	slug text,
	source_id uuid,
	source text,
	date_published timestamp without time zone,
	date_modified timestamp without time zone,
	section text,
	description text,
	aotd_timestamp timestamp without time zone,
	score integer,
	url text,
	authors text[],
	tags text[],
	word_count bigint,
	readable_word_count bigint,
	page_count bigint,
	comment_count bigint,
	latest_comment_date timestamp without time zone,
	read_count bigint,
	latest_read_date timestamp without time zone,
	total_count bigint
);


ALTER TYPE article_page_result OWNER TO postgres;

--
-- Name: create_article_author; Type: TYPE; Schema: article_api; Owner: postgres
--

CREATE TYPE create_article_author AS (
	name text,
	url text
);


ALTER TYPE create_article_author OWNER TO postgres;

--
-- Name: user_article_page_result; Type: TYPE; Schema: article_api; Owner: postgres
--

CREATE TYPE user_article_page_result AS (
	id uuid,
	title text,
	slug text,
	source_id uuid,
	source text,
	date_published timestamp without time zone,
	date_modified timestamp without time zone,
	section text,
	description text,
	aotd_timestamp timestamp without time zone,
	score integer,
	url text,
	authors text[],
	tags text[],
	word_count bigint,
	readable_word_count bigint,
	page_count bigint,
	comment_count bigint,
	latest_comment_date timestamp without time zone,
	read_count bigint,
	latest_read_date timestamp without time zone,
	user_account_id uuid,
	words_read bigint,
	date_created timestamp without time zone,
	last_modified timestamp without time zone,
	percent_complete double precision,
	is_read boolean,
	date_starred timestamp without time zone,
	total_count bigint
);


ALTER TYPE user_article_page_result OWNER TO postgres;

--
-- Name: user_comment_page_result; Type: TYPE; Schema: article_api; Owner: postgres
--

CREATE TYPE user_comment_page_result AS (
	id uuid,
	date_created timestamp without time zone,
	text text,
	article_id uuid,
	article_title text,
	article_slug text,
	user_account_id uuid,
	user_account text,
	parent_comment_id uuid,
	date_read timestamp without time zone,
	total_count bigint
);


ALTER TYPE user_comment_page_result OWNER TO postgres;

SET search_path = bulk_mailing_api, pg_catalog;

--
-- Name: create_bulk_mailing_recipient; Type: TYPE; Schema: bulk_mailing_api; Owner: postgres
--

CREATE TYPE create_bulk_mailing_recipient AS (
	user_account_id uuid,
	is_successful boolean
);


ALTER TYPE create_bulk_mailing_recipient OWNER TO postgres;

SET search_path = core, pg_catalog;

--
-- Name: source_rule_action; Type: TYPE; Schema: core; Owner: postgres
--

CREATE TYPE source_rule_action AS ENUM (
    'default',
    'read',
    'ignore'
);


ALTER TYPE source_rule_action OWNER TO postgres;

--
-- Name: user_account_role; Type: TYPE; Schema: core; Owner: postgres
--

CREATE TYPE user_account_role AS ENUM (
    'regular',
    'admin'
);


ALTER TYPE user_account_role OWNER TO postgres;

SET search_path = article_api, pg_catalog;

--
-- Name: create_article(text, text, uuid, timestamp without time zone, timestamp without time zone, text, text, create_article_author[], text[]); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION create_article(title text, slug text, source_id uuid, date_published timestamp without time zone, date_modified timestamp without time zone, section text, description text, authors create_article_author[], tags text[]) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
	article_id	 		uuid;
	current_author		article_api.create_article_author;
	current_author_id	uuid;
	current_tag			text;
	current_tag_id		uuid;
BEGIN
	INSERT INTO article (title, slug, source_id, date_published, date_modified, section, description)
		VALUES (title, slug, source_id, date_published, date_modified, section, description)
		RETURNING id INTO article_id;
	FOREACH current_author IN ARRAY authors
	LOOP
		SELECT id INTO current_author_id FROM author WHERE url = current_author.url;
		IF current_author_id IS NULL THEN
			INSERT INTO author (name, url) VALUES (current_author.name, current_author.url)
				RETURNING id INTO current_author_id;
		END IF;
		INSERT INTO article_author (article_id, author_id) VALUES (article_id, current_author_id);
	END LOOP;
	FOREACH current_tag IN ARRAY tags
	LOOP
		SELECT id INTO current_tag_id FROM tag WHERE name = current_tag;
		IF current_tag_id IS NULL THEN
			INSERT INTO tag (name) VALUES (current_tag) RETURNING id INTO current_tag_id;
		END IF;
		INSERT INTO article_tag (article_id, tag_id) VALUES (article_id, current_tag_id);
	END LOOP;
	RETURN article_id;
END;
$$;


ALTER FUNCTION article_api.create_article(title text, slug text, source_id uuid, date_published timestamp without time zone, date_modified timestamp without time zone, section text, description text, authors create_article_author[], tags text[]) OWNER TO postgres;

SET search_path = core, pg_catalog;

--
-- Name: utc_now(); Type: FUNCTION; Schema: core; Owner: postgres
--

CREATE FUNCTION utc_now() RETURNS timestamp without time zone
    LANGUAGE sql
    AS $$
	SELECT CURRENT_TIMESTAMP AT TIME ZONE 'UTC';
$$;


ALTER FUNCTION core.utc_now() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: article; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE article (
    id uuid DEFAULT pgcrypto.gen_random_uuid() NOT NULL,
    title character varying(512) NOT NULL,
    slug character varying(256) NOT NULL,
    source_id uuid NOT NULL,
    date_published timestamp without time zone,
    date_modified timestamp without time zone,
    section character varying(256),
    description text,
    aotd_timestamp timestamp without time zone,
    score integer DEFAULT 0 NOT NULL
);


ALTER TABLE article OWNER TO postgres;

--
-- Name: comment; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE comment (
    id uuid DEFAULT pgcrypto.gen_random_uuid() NOT NULL,
    date_created timestamp without time zone DEFAULT utc_now() NOT NULL,
    text text NOT NULL,
    article_id uuid NOT NULL,
    user_account_id uuid NOT NULL,
    parent_comment_id uuid,
    date_read timestamp without time zone
);


ALTER TABLE comment OWNER TO postgres;

--
-- Name: user_account; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE user_account (
    id uuid DEFAULT pgcrypto.gen_random_uuid() NOT NULL,
    name character varying(30) NOT NULL,
    email character varying(256) NOT NULL,
    password_hash bytea NOT NULL,
    password_salt bytea NOT NULL,
    receive_reply_email_notifications boolean DEFAULT true NOT NULL,
    receive_reply_desktop_notifications boolean DEFAULT true NOT NULL,
    last_new_reply_ack timestamp without time zone DEFAULT utc_now() NOT NULL,
    last_new_reply_desktop_notification timestamp without time zone DEFAULT utc_now() NOT NULL,
    date_created timestamp without time zone DEFAULT utc_now() NOT NULL,
    role user_account_role DEFAULT 'regular'::user_account_role NOT NULL,
    receive_website_updates boolean DEFAULT true,
    receive_suggested_readings boolean DEFAULT true,
    CONSTRAINT user_account_email_valid CHECK (((email)::text ~~ '%@%'::text)),
    CONSTRAINT user_account_name_valid CHECK (((name)::text ~ similar_escape('[A-Za-z0-9\-_]+'::text, NULL::text)))
);


ALTER TABLE user_account OWNER TO postgres;

SET search_path = article_api, pg_catalog;

--
-- Name: user_comment; Type: VIEW; Schema: article_api; Owner: postgres
--

CREATE VIEW user_comment AS
 SELECT comment.id,
    comment.date_created,
    comment.text,
    comment.article_id,
    article.title AS article_title,
    article.slug AS article_slug,
    comment.user_account_id,
    user_account.name AS user_account,
    comment.parent_comment_id,
    comment.date_read
   FROM ((core.comment
     JOIN core.article ON ((comment.article_id = article.id)))
     JOIN core.user_account ON ((comment.user_account_id = user_account.id)));


ALTER TABLE user_comment OWNER TO postgres;

--
-- Name: create_comment(text, uuid, uuid, uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION create_comment(text text, article_id uuid, parent_comment_id uuid, user_account_id uuid) RETURNS SETOF user_comment
    LANGUAGE plpgsql
    AS $$
DECLARE
  comment_id uuid;
BEGIN
	INSERT INTO comment
        (text, article_id, parent_comment_id, user_account_id) VALUES
        (text, article_id, parent_comment_id, user_account_id) RETURNING id INTO comment_id;
    RETURN QUERY SELECT * FROM article_api.user_comment WHERE id = comment_id;
END;
$$;


ALTER FUNCTION article_api.create_comment(text text, article_id uuid, parent_comment_id uuid, user_account_id uuid) OWNER TO postgres;

SET search_path = core, pg_catalog;

--
-- Name: page; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE page (
    id uuid DEFAULT pgcrypto.gen_random_uuid() NOT NULL,
    article_id uuid NOT NULL,
    number integer NOT NULL,
    word_count integer NOT NULL,
    readable_word_count integer NOT NULL,
    url character varying(256) NOT NULL
);


ALTER TABLE page OWNER TO postgres;

SET search_path = article_api, pg_catalog;

--
-- Name: create_page(uuid, integer, integer, integer, text); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION create_page(article_id uuid, number integer, word_count integer, readable_word_count integer, url text) RETURNS core.page
    LANGUAGE sql
    AS $$
	INSERT INTO page (article_id, number, word_count, readable_word_count, url)
		VALUES (article_id, number, word_count, readable_word_count, url)
		RETURNING *;
$$;


ALTER FUNCTION article_api.create_page(article_id uuid, number integer, word_count integer, readable_word_count integer, url text) OWNER TO postgres;

SET search_path = core, pg_catalog;

--
-- Name: source; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE source (
    id uuid DEFAULT pgcrypto.gen_random_uuid() NOT NULL,
    name character varying(256),
    url character varying(256) NOT NULL,
    hostname character varying(256) NOT NULL,
    slug character varying(256) NOT NULL,
    parser text
);


ALTER TABLE source OWNER TO postgres;

SET search_path = article_api, pg_catalog;

--
-- Name: create_source(text, text, text, text); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION create_source(name text, url text, hostname text, slug text) RETURNS core.source
    LANGUAGE sql
    AS $$
	INSERT INTO source (name, url, hostname, slug) VALUES (name, url, hostname, slug) RETURNING *;
$$;


ALTER FUNCTION article_api.create_source(name text, url text, hostname text, slug text) OWNER TO postgres;

SET search_path = core, pg_catalog;

--
-- Name: user_page; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE user_page (
    id uuid DEFAULT pgcrypto.gen_random_uuid() NOT NULL,
    page_id uuid NOT NULL,
    user_account_id uuid NOT NULL,
    date_created timestamp without time zone DEFAULT utc_now() NOT NULL,
    last_modified timestamp without time zone,
    read_state integer[] NOT NULL,
    words_read integer DEFAULT 0 NOT NULL
);


ALTER TABLE user_page OWNER TO postgres;

SET search_path = article_api, pg_catalog;

--
-- Name: create_user_page(uuid, uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION create_user_page(page_id uuid, user_account_id uuid) RETURNS core.user_page
    LANGUAGE sql
    AS $$
	INSERT INTO user_page (page_id, user_account_id, read_state)
	VALUES (
		page_id,
		user_account_id,
		ARRAY[(SELECT -word_count FROM page WHERE id = page_id)]
	)
	RETURNING *;
$$;


ALTER FUNCTION article_api.create_user_page(page_id uuid, user_account_id uuid) OWNER TO postgres;

--
-- Name: delete_article(uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION delete_article(id uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	DELETE FROM user_page WHERE page_id IN (SELECT page.id FROM page WHERE article_id = delete_article.id);
	DELETE FROM page WHERE article_id = delete_article.id;
	DELETE FROM article_author WHERE article_id = delete_article.id;
	DELETE FROM article_tag WHERE article_id = delete_article.id;
	DELETE FROM article WHERE article.id = delete_article.id;
END;
$$;


ALTER FUNCTION article_api.delete_article(id uuid) OWNER TO postgres;

--
-- Name: delete_user_article(uuid, uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION delete_user_article(article_id uuid, user_account_id uuid) RETURNS void
    LANGUAGE sql
    AS $$
	DELETE FROM user_page
		WHERE page_id IN (SELECT id FROM page WHERE page.article_id = delete_user_article.article_id) AND
			  user_page.user_account_id = delete_user_article.user_account_id;
$$;


ALTER FUNCTION article_api.delete_user_article(article_id uuid, user_account_id uuid) OWNER TO postgres;

--
-- Name: article; Type: TABLE; Schema: article_api; Owner: postgres
--

CREATE TABLE article (
    id uuid,
    title character varying(512),
    slug character varying(256),
    source_id uuid,
    source character varying(256),
    date_published timestamp without time zone,
    date_modified timestamp without time zone,
    section character varying(256),
    description text,
    aotd_timestamp timestamp without time zone,
    score integer,
    url character varying,
    authors text[],
    tags text[],
    word_count bigint,
    readable_word_count bigint,
    page_count bigint,
    comment_count bigint,
    latest_comment_date timestamp without time zone,
    read_count bigint,
    latest_read_date timestamp without time zone
);

ALTER TABLE ONLY article REPLICA IDENTITY NOTHING;


ALTER TABLE article OWNER TO postgres;

--
-- Name: find_article(text); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION find_article(slug text) RETURNS SETOF article
    LANGUAGE sql
    AS $$
	SELECT
		id,
		title,
		slug,
		source_id,
		source,
		date_published,
		date_modified,
		section,
		description,
		aotd_timestamp,
		score,
		url,
		authors,
		tags,
		word_count,
		readable_word_count,
		page_count,
		comment_count,
		latest_comment_date,
		read_count,
		latest_read_date
	FROM article_api.article
	WHERE slug = find_article.slug;
$$;


ALTER FUNCTION article_api.find_article(slug text) OWNER TO postgres;

--
-- Name: find_page(text); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION find_page(url text) RETURNS SETOF core.page
    LANGUAGE sql
    AS $$
	SELECT * FROM page WHERE url = find_page.url;
$$;


ALTER FUNCTION article_api.find_page(url text) OWNER TO postgres;

--
-- Name: find_source(text); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION find_source(source_hostname text) RETURNS SETOF core.source
    LANGUAGE sql
    AS $$
	SELECT * FROM source WHERE hostname = source_hostname;
$$;


ALTER FUNCTION article_api.find_source(source_hostname text) OWNER TO postgres;

--
-- Name: article_pages; Type: VIEW; Schema: article_api; Owner: postgres
--

CREATE VIEW article_pages AS
 SELECT array_agg(page.url ORDER BY page.number) AS urls,
    count(*) AS count,
    sum(page.word_count) AS word_count,
    sum(page.readable_word_count) AS readable_word_count,
    page.article_id
   FROM core.page
  GROUP BY page.article_id;


ALTER TABLE article_pages OWNER TO postgres;

--
-- Name: user_article_progress; Type: VIEW; Schema: article_api; Owner: postgres
--

CREATE VIEW user_article_progress AS
 WITH user_article_pages AS (
         SELECT sum(user_page.words_read) AS words_read,
            min(user_page.date_created) AS date_created,
            max(user_page.last_modified) AS last_modified,
            user_page.user_account_id,
            page.article_id
           FROM (core.user_page
             JOIN core.page ON ((page.id = user_page.page_id)))
          GROUP BY user_page.user_account_id, page.article_id
        )
 SELECT user_article_progress.words_read,
    user_article_progress.date_created,
    user_article_progress.last_modified,
    user_article_progress.percent_complete,
    (user_article_progress.percent_complete >= (90)::double precision) AS is_read,
    user_article_progress.user_account_id,
    user_article_progress.article_id
   FROM ( SELECT user_article_pages.words_read,
            user_article_pages.date_created,
            user_article_pages.last_modified,
            LEAST((((user_article_pages.words_read)::double precision / (article_pages.readable_word_count)::double precision) * (100)::double precision), (100)::double precision) AS percent_complete,
            user_article_pages.user_account_id,
            user_article_pages.article_id
           FROM (user_article_pages
             JOIN article_pages ON ((article_pages.article_id = user_article_pages.article_id)))) user_article_progress
  GROUP BY user_article_progress.words_read, user_article_progress.date_created, user_article_progress.last_modified, user_article_progress.percent_complete, user_article_progress.user_account_id, user_article_progress.article_id;


ALTER TABLE user_article_progress OWNER TO postgres;

SET search_path = core, pg_catalog;

--
-- Name: star; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE star (
    user_account_id uuid NOT NULL,
    article_id uuid NOT NULL,
    date_starred timestamp without time zone DEFAULT utc_now() NOT NULL
);


ALTER TABLE star OWNER TO postgres;

SET search_path = article_api, pg_catalog;

--
-- Name: user_article; Type: VIEW; Schema: article_api; Owner: postgres
--

CREATE VIEW user_article AS
 SELECT article.id,
    article.title,
    article.slug,
    article.source_id,
    article.source,
    article.date_published,
    article.date_modified,
    article.section,
    article.description,
    article.aotd_timestamp,
    article.score,
    article.url,
    article.authors,
    article.tags,
    article.word_count,
    article.readable_word_count,
    article.page_count,
    article.comment_count,
    article.latest_comment_date,
    article.read_count,
    article.latest_read_date,
    user_account.id AS user_account_id,
    COALESCE(user_article_progress.words_read, (0)::bigint) AS words_read,
    user_article_progress.date_created,
    user_article_progress.last_modified,
    COALESCE(user_article_progress.percent_complete, (0)::double precision) AS percent_complete,
    COALESCE(user_article_progress.is_read, false) AS is_read,
    star.date_starred
   FROM (((article
     CROSS JOIN core.user_account)
     LEFT JOIN user_article_progress ON (((user_article_progress.user_account_id = user_account.id) AND (user_article_progress.article_id = article.id))))
     LEFT JOIN core.star ON (((star.user_account_id = user_account.id) AND (star.article_id = article.id))))
  GROUP BY article.id, article.title, article.slug, article.source_id, article.source, article.date_published, article.date_modified, article.section, article.description, article.aotd_timestamp, article.score, article.url, article.authors, article.tags, article.word_count, article.readable_word_count, article.page_count, article.comment_count, article.latest_comment_date, article.read_count, article.latest_read_date, user_account.id, user_article_progress.words_read, user_article_progress.date_created, user_article_progress.last_modified, user_article_progress.percent_complete, user_article_progress.is_read, star.date_starred;


ALTER TABLE user_article OWNER TO postgres;

--
-- Name: find_user_article(text, uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION find_user_article(slug text, user_account_id uuid) RETURNS SETOF user_article
    LANGUAGE sql
    AS $$
	SELECT
		id,
		title,
		slug,
		source_id,
		source,
		date_published,
		date_modified,
		section,
		description,
		aotd_timestamp,
		score,
		url,
		authors,
		tags,
		word_count,
		readable_word_count,
		page_count,
		comment_count,
		latest_comment_date,
		read_count,
		latest_read_date,
		user_account_id,
		words_read,
		date_created,
		last_modified,
		percent_complete,
		is_read,
		date_starred
	FROM article_api.user_article
	WHERE
		slug = find_user_article.slug AND
		user_account_id = find_user_article.user_account_id;
$$;


ALTER FUNCTION article_api.find_user_article(slug text, user_account_id uuid) OWNER TO postgres;

--
-- Name: get_aotd(); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION get_aotd() RETURNS SETOF article
    LANGUAGE sql
    AS $$
	SELECT
		id,
		title,
		slug,
		source_id,
		source,
		date_published,
		date_modified,
		section,
		description,
		aotd_timestamp,
		score,
		url,
		authors,
		tags,
		word_count,
		readable_word_count,
		page_count,
		comment_count,
		latest_comment_date,
		read_count,
		latest_read_date
	FROM article_api.article
	WHERE id = (
		SELECT id
		FROM core.article
		ORDER BY core.article.aotd_timestamp DESC NULLS LAST
		LIMIT 1
	);
$$;


ALTER FUNCTION article_api.get_aotd() OWNER TO postgres;

--
-- Name: get_comment(uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION get_comment(comment_id uuid) RETURNS SETOF user_comment
    LANGUAGE sql
    AS $$
	SELECT * FROM article_api.user_comment WHERE id = comment_id;
$$;


ALTER FUNCTION article_api.get_comment(comment_id uuid) OWNER TO postgres;

--
-- Name: get_page(uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION get_page(page_id uuid) RETURNS SETOF core.page
    LANGUAGE sql
    AS $$
	SELECT * FROM page WHERE id = page_id;
$$;


ALTER FUNCTION article_api.get_page(page_id uuid) OWNER TO postgres;

SET search_path = core, pg_catalog;

--
-- Name: source_rule; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE source_rule (
    id uuid DEFAULT pgcrypto.gen_random_uuid() NOT NULL,
    hostname character varying(256) NOT NULL,
    path character varying(256) NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    action source_rule_action NOT NULL
);


ALTER TABLE source_rule OWNER TO postgres;

SET search_path = article_api, pg_catalog;

--
-- Name: get_source_rules(); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION get_source_rules() RETURNS SETOF core.source_rule
    LANGUAGE sql
    AS $$
	SELECT * FROM source_rule;
$$;


ALTER FUNCTION article_api.get_source_rules() OWNER TO postgres;

--
-- Name: get_user_aotd(uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION get_user_aotd(user_account_id uuid) RETURNS SETOF user_article
    LANGUAGE sql
    AS $$
	SELECT
		id,
		title,
		slug,
		source_id,
		source,
		date_published,
		date_modified,
		section,
		description,
		aotd_timestamp,
		score,
		url,
		authors,
		tags,
		word_count,
		readable_word_count,
		page_count,
		comment_count,
		latest_comment_date,
		read_count,
		latest_read_date,
		user_account_id,
		words_read,
		date_created,
		last_modified,
		percent_complete,
		is_read,
		date_starred
	FROM article_api.user_article
	WHERE
		id = (
			SELECT id
			FROM core.article
			ORDER BY core.article.aotd_timestamp DESC NULLS LAST
			LIMIT 1
		) AND
		user_account_id = get_user_aotd.user_account_id;
$$;


ALTER FUNCTION article_api.get_user_aotd(user_account_id uuid) OWNER TO postgres;

--
-- Name: get_user_article(uuid, uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION get_user_article(article_id uuid, user_account_id uuid) RETURNS SETOF user_article
    LANGUAGE sql
    AS $$
	SELECT
		id,
		title,
		slug,
		source_id,
		source,
		date_published,
		date_modified,
		section,
		description,
		aotd_timestamp,
		score,
		url,
		authors,
		tags,
		word_count,
		readable_word_count,
		page_count,
		comment_count,
		latest_comment_date,
		read_count,
		latest_read_date,
		user_account_id,
		words_read,
		date_created,
		last_modified,
		percent_complete,
		is_read,
		date_starred
	FROM article_api.user_article
	WHERE
		id = article_id AND
		user_account_id = get_user_article.user_account_id;
$$;


ALTER FUNCTION article_api.get_user_article(article_id uuid, user_account_id uuid) OWNER TO postgres;

--
-- Name: get_user_page(uuid, uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION get_user_page(page_id uuid, user_account_id uuid) RETURNS SETOF core.user_page
    LANGUAGE sql
    AS $$
	SELECT * FROM user_page WHERE
		page_id = get_user_page.page_id AND
		user_account_id = get_user_page.user_account_id;
$$;


ALTER FUNCTION article_api.get_user_page(page_id uuid, user_account_id uuid) OWNER TO postgres;

--
-- Name: list_comments(uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION list_comments(article_id uuid) RETURNS SETOF user_comment
    LANGUAGE sql
    AS $$
	SELECT * FROM article_api.user_comment WHERE article_id = list_comments.article_id;
$$;


ALTER FUNCTION article_api.list_comments(article_id uuid) OWNER TO postgres;

--
-- Name: list_hot_topics(integer, integer); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION list_hot_topics(page_number integer, page_size integer) RETURNS SETOF article_page_result
    LANGUAGE sql
    AS $$
	SELECT
		id,
		title,
		slug,
		source_id,
		source,
		date_published,
		date_modified,
		section,
		description,
		aotd_timestamp,
		score,
		url,
		authors,
		tags,
		word_count,
		readable_word_count,
		page_count,
		comment_count,
		latest_comment_date,
		read_count,
		latest_read_date,
		count(*) OVER() AS total_count
	FROM article_api.article
	WHERE
		(comment_count > 0 OR read_count > 1) AND
		(aotd_timestamp IS NULL OR aotd_timestamp != (SELECT max(aotd_timestamp) FROM article))
	ORDER BY score DESC
	OFFSET (page_number - 1) * page_size
	LIMIT page_size;
$$;


ALTER FUNCTION article_api.list_hot_topics(page_number integer, page_size integer) OWNER TO postgres;

--
-- Name: list_replies(uuid, integer, integer); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION list_replies(user_account_id uuid, page_number integer, page_size integer) RETURNS SETOF user_comment_page_result
    LANGUAGE sql
    AS $$
	SELECT
		reply.id,
		reply.date_created,
		reply.text,
		reply.article_id,
		reply.article_title,
		reply.article_slug,
		reply.user_account_id,
		reply.user_account,
		reply.parent_comment_id,
		reply.date_read,
		count(*) OVER() AS total_count
	FROM
		article_api.user_comment AS reply
		JOIN comment AS parent ON reply.parent_comment_id = parent.id
	WHERE parent.user_account_id = list_replies.user_account_id
	ORDER BY reply.date_created DESC
	OFFSET (page_number - 1) * page_size
	LIMIT page_size;
$$;


ALTER FUNCTION article_api.list_replies(user_account_id uuid, page_number integer, page_size integer) OWNER TO postgres;

--
-- Name: list_starred_articles(uuid, integer, integer); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION list_starred_articles(user_account_id uuid, page_number integer, page_size integer) RETURNS SETOF user_article_page_result
    LANGUAGE sql
    AS $$
	SELECT
		id,
		title,
		slug,
		source_id,
		source,
		date_published,
		date_modified,
		section,
		description,
		aotd_timestamp,
		score,
		url,
		authors,
		tags,
		word_count,
		readable_word_count,
		page_count,
		comment_count,
		latest_comment_date,
		read_count,
		latest_read_date,
		user_account_id,
		words_read,
		date_created,
		last_modified,
		percent_complete,
		is_read,
		date_starred,
		count(*) OVER() AS total_count
	FROM article_api.user_article
	WHERE
		user_account_id = list_starred_articles.user_account_id AND
		date_starred IS NOT NULL
	ORDER BY date_starred DESC
	OFFSET (page_number - 1) * page_size
	LIMIT page_size;
$$;


ALTER FUNCTION article_api.list_starred_articles(user_account_id uuid, page_number integer, page_size integer) OWNER TO postgres;

--
-- Name: list_user_article_history(uuid, integer, integer); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION list_user_article_history(user_account_id uuid, page_number integer, page_size integer) RETURNS SETOF user_article_page_result
    LANGUAGE sql
    AS $$
	SELECT
		id,
		title,
		slug,
		source_id,
		source,
		date_published,
		date_modified,
		section,
		description,
		aotd_timestamp,
		score,
		url,
		authors,
		tags,
		word_count,
		readable_word_count,
		page_count,
		comment_count,
		latest_comment_date,
		read_count,
		latest_read_date,
		user_account_id,
		words_read,
		date_created,
		last_modified,
		percent_complete,
		is_read,
		date_starred,
		count(*) OVER() AS total_count
	FROM article_api.user_article
	WHERE
		user_account_id = list_user_article_history.user_account_id AND
		(date_starred IS NOT NULL OR date_created IS NOT NULL)
	ORDER BY greatest(date_starred, date_created) DESC
	OFFSET (page_number - 1) * page_size
	LIMIT page_size;
$$;


ALTER FUNCTION article_api.list_user_article_history(user_account_id uuid, page_number integer, page_size integer) OWNER TO postgres;

--
-- Name: list_user_hot_topics(uuid, integer, integer); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION list_user_hot_topics(user_account_id uuid, page_number integer, page_size integer) RETURNS SETOF user_article_page_result
    LANGUAGE sql
    AS $$
	SELECT
		id,
		title,
		slug,
		source_id,
		source,
		date_published,
		date_modified,
		section,
		description,
		aotd_timestamp,
		score,
		url,
		authors,
		tags,
		word_count,
		readable_word_count,
		page_count,
		comment_count,
		latest_comment_date,
		read_count,
		latest_read_date,
		user_account_id,
		words_read,
		date_created,
		last_modified,
		percent_complete,
		is_read,
		date_starred,
		count(*) OVER() AS total_count
	FROM article_api.user_article
	WHERE
		user_account_id = list_user_hot_topics.user_account_id AND
		(comment_count > 0 OR read_count > 1) AND
		(aotd_timestamp IS NULL OR aotd_timestamp != (SELECT max(aotd_timestamp) FROM article))
	ORDER BY score DESC
	OFFSET (page_number - 1) * page_size
	LIMIT page_size;
$$;


ALTER FUNCTION article_api.list_user_hot_topics(user_account_id uuid, page_number integer, page_size integer) OWNER TO postgres;

--
-- Name: read_comment(uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION read_comment(comment_id uuid) RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE comment SET date_read = utc_now() WHERE id = comment_id AND date_read IS NULL;
$$;


ALTER FUNCTION article_api.read_comment(comment_id uuid) OWNER TO postgres;

--
-- Name: score_articles(); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION score_articles() RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE article
	SET score = article_score.score
	FROM article_api.article_score
	WHERE article_score.article_id = article.id;
$$;


ALTER FUNCTION article_api.score_articles() OWNER TO postgres;

--
-- Name: set_aotd(); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION set_aotd() RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE article
	SET aotd_timestamp = utc_now()
	WHERE id = (
		SELECT id
		FROM article
		WHERE aotd_timestamp IS NULL
		ORDER BY score DESC
		LIMIT 1
	);
$$;


ALTER FUNCTION article_api.set_aotd() OWNER TO postgres;

--
-- Name: star_article(uuid, uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION star_article(user_account_id uuid, article_id uuid) RETURNS void
    LANGUAGE sql
    AS $$
	INSERT INTO star (user_account_id, article_id) VALUES (user_account_id, article_id);
$$;


ALTER FUNCTION article_api.star_article(user_account_id uuid, article_id uuid) OWNER TO postgres;

--
-- Name: unstar_article(uuid, uuid); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION unstar_article(user_account_id uuid, article_id uuid) RETURNS void
    LANGUAGE sql
    AS $$
	DELETE FROM star WHERE
		user_account_id = unstar_article.user_account_id AND
		article_id = unstar_article.article_id;
$$;


ALTER FUNCTION article_api.unstar_article(user_account_id uuid, article_id uuid) OWNER TO postgres;

--
-- Name: update_user_page(uuid, integer[]); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION update_user_page(user_page_id uuid, read_state integer[]) RETURNS core.user_page
    LANGUAGE sql
    AS $$
	UPDATE user_page SET
			read_state = update_user_page.read_state,
			words_read = (SELECT SUM(n) FROM UNNEST(update_user_page.read_state) AS n WHERE n > 0),
			last_modified = utc_now()
		WHERE id = user_page_id
	RETURNING *;
$$;


ALTER FUNCTION article_api.update_user_page(user_page_id uuid, read_state integer[]) OWNER TO postgres;

SET search_path = bulk_mailing_api, pg_catalog;

--
-- Name: create_bulk_mailing(text, text, text, uuid, create_bulk_mailing_recipient[]); Type: FUNCTION; Schema: bulk_mailing_api; Owner: postgres
--

CREATE FUNCTION create_bulk_mailing(subject text, body text, list text, user_account_id uuid, recipients create_bulk_mailing_recipient[]) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
	bulk_mailing_id	uuid;
	recipient		bulk_mailing_api.create_bulk_mailing_recipient;
BEGIN
	INSERT INTO bulk_mailing (subject, body, list, user_account_id)
		VALUES (subject, body, list, user_account_id)
		RETURNING id INTO bulk_mailing_id;
	FOREACH recipient IN ARRAY recipients
	LOOP
		INSERT INTO bulk_mailing_recipient (bulk_mailing_id, user_account_id, is_successful)
			VALUES (bulk_mailing_id, recipient.user_account_id, recipient.is_successful);
	END LOOP;
	RETURN bulk_mailing_id;
END;
$$;


ALTER FUNCTION bulk_mailing_api.create_bulk_mailing(subject text, body text, list text, user_account_id uuid, recipients create_bulk_mailing_recipient[]) OWNER TO postgres;

--
-- Name: list_bulk_mailings(); Type: FUNCTION; Schema: bulk_mailing_api; Owner: postgres
--

CREATE FUNCTION list_bulk_mailings() RETURNS TABLE(id uuid, date_sent timestamp without time zone, subject text, body text, list text, user_account text, recipient_count bigint, error_count bigint)
    LANGUAGE sql
    AS $$
	SELECT
		bulk_mailing.id,
		bulk_mailing.date_sent,
		bulk_mailing.subject,
		bulk_mailing.body,
		bulk_mailing.list,
		user_account.name AS user_account,
		count(*) AS recipient_count,
		count(*) FILTER (WHERE NOT bulk_mailing_recipient.is_successful) AS error_count
		FROM bulk_mailing
		JOIN user_account ON bulk_mailing.user_account_id = user_account.id
		JOIN bulk_mailing_recipient ON bulk_mailing.id = bulk_mailing_recipient.bulk_mailing_id
		GROUP BY bulk_mailing.id, user_account.id;
$$;


ALTER FUNCTION bulk_mailing_api.list_bulk_mailings() OWNER TO postgres;

SET search_path = core, pg_catalog;

--
-- Name: email_bounce; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE email_bounce (
    id uuid DEFAULT pgcrypto.gen_random_uuid() NOT NULL,
    date_received timestamp without time zone NOT NULL,
    address text NOT NULL,
    message text NOT NULL,
    bulk_mailing_id uuid
);


ALTER TABLE email_bounce OWNER TO postgres;

SET search_path = bulk_mailing_api, pg_catalog;

--
-- Name: list_email_bounces(); Type: FUNCTION; Schema: bulk_mailing_api; Owner: postgres
--

CREATE FUNCTION list_email_bounces() RETURNS SETOF core.email_bounce
    LANGUAGE sql
    AS $$
	SELECT
		id,
		date_received,
		address,
		message,
		bulk_mailing_id
	FROM email_bounce;
$$;


ALTER FUNCTION bulk_mailing_api.list_email_bounces() OWNER TO postgres;

SET search_path = user_account_api, pg_catalog;

--
-- Name: ack_new_reply(uuid); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION ack_new_reply(user_account_id uuid) RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE user_account SET last_new_reply_ack = utc_now() WHERE id = user_account_id;
$$;


ALTER FUNCTION user_account_api.ack_new_reply(user_account_id uuid) OWNER TO postgres;

--
-- Name: change_email_address(uuid, text); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION change_email_address(user_account_id uuid, email text) RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE user_account
		SET email = change_email_address.email
		WHERE id = user_account_id;
$$;


ALTER FUNCTION user_account_api.change_email_address(user_account_id uuid, email text) OWNER TO postgres;

--
-- Name: change_password(uuid, bytea, bytea); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION change_password(user_account_id uuid, password_hash bytea, password_salt bytea) RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE user_account
		SET
			password_hash = change_password.password_hash,
			password_salt = change_password.password_salt
		WHERE id = user_account_id;
$$;


ALTER FUNCTION user_account_api.change_password(user_account_id uuid, password_hash bytea, password_salt bytea) OWNER TO postgres;

--
-- Name: complete_password_reset_request(uuid); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION complete_password_reset_request(password_reset_request_id uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
	rows_updated int;
BEGIN
	UPDATE password_reset_request
		SET date_completed = utc_now()
		WHERE id = password_reset_request_id AND date_completed IS NULL;
	GET DIAGNOSTICS rows_updated = ROW_COUNT;
	RETURN rows_updated = 1;
END;
$$;


ALTER FUNCTION user_account_api.complete_password_reset_request(password_reset_request_id uuid) OWNER TO postgres;

--
-- Name: confirm_email_address(uuid); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION confirm_email_address(email_confirmation_id uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
	rows_updated int;
BEGIN
	UPDATE email_confirmation SET date_confirmed = utc_now() WHERE id = email_confirmation_id AND date_confirmed IS NULL;
	GET DIAGNOSTICS rows_updated = ROW_COUNT;
	RETURN rows_updated = 1;
END;
$$;


ALTER FUNCTION user_account_api.confirm_email_address(email_confirmation_id uuid) OWNER TO postgres;

SET search_path = core, pg_catalog;

--
-- Name: email_confirmation; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE email_confirmation (
    id uuid DEFAULT pgcrypto.gen_random_uuid() NOT NULL,
    date_created timestamp without time zone DEFAULT utc_now() NOT NULL,
    user_account_id uuid NOT NULL,
    email_address text NOT NULL,
    date_confirmed timestamp without time zone
);


ALTER TABLE email_confirmation OWNER TO postgres;

SET search_path = user_account_api, pg_catalog;

--
-- Name: create_email_confirmation(uuid); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION create_email_confirmation(user_account_id uuid) RETURNS SETOF core.email_confirmation
    LANGUAGE sql
    AS $$
	INSERT INTO email_confirmation (user_account_id, email_address)
		VALUES (user_account_id, (SELECT email FROM user_account WHERE id = user_account_id))
		RETURNING *;
$$;


ALTER FUNCTION user_account_api.create_email_confirmation(user_account_id uuid) OWNER TO postgres;

SET search_path = core, pg_catalog;

--
-- Name: password_reset_request; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE password_reset_request (
    id uuid DEFAULT pgcrypto.gen_random_uuid() NOT NULL,
    date_created timestamp without time zone DEFAULT utc_now() NOT NULL,
    user_account_id uuid NOT NULL,
    email_address text NOT NULL,
    date_completed timestamp without time zone
);


ALTER TABLE password_reset_request OWNER TO postgres;

SET search_path = user_account_api, pg_catalog;

--
-- Name: create_password_reset_request(uuid); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION create_password_reset_request(user_account_id uuid) RETURNS SETOF core.password_reset_request
    LANGUAGE sql
    AS $$
	INSERT INTO password_reset_request (user_account_id, email_address)
		VALUES (user_account_id, (SELECT email FROM user_account WHERE id = user_account_id))
		RETURNING *;
$$;


ALTER FUNCTION user_account_api.create_password_reset_request(user_account_id uuid) OWNER TO postgres;

--
-- Name: user_account; Type: VIEW; Schema: user_account_api; Owner: postgres
--

CREATE VIEW user_account AS
 SELECT user_account.id,
    user_account.name,
    user_account.email,
    user_account.password_hash,
    user_account.password_salt,
    user_account.receive_reply_email_notifications,
    user_account.receive_reply_desktop_notifications,
    user_account.last_new_reply_ack,
    user_account.last_new_reply_desktop_notification,
    user_account.date_created,
    user_account.role,
    user_account.receive_website_updates,
    user_account.receive_suggested_readings,
    (ec.date_confirmed IS NOT NULL) AS is_email_confirmed
   FROM ((core.user_account
     LEFT JOIN core.email_confirmation ec ON ((ec.user_account_id = user_account.id)))
     LEFT JOIN core.email_confirmation ec1 ON (((ec1.user_account_id = user_account.id) AND (ec1.date_created > ec.date_created))))
  WHERE (ec1.id IS NULL);


ALTER TABLE user_account OWNER TO postgres;

--
-- Name: create_user_account(text, text, bytea, bytea); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION create_user_account(name text, email text, password_hash bytea, password_salt bytea) RETURNS SETOF user_account
    LANGUAGE plpgsql
    AS $$
DECLARE
	user_account_id uuid;
BEGIN
	INSERT INTO user_account (name, email, password_hash, password_salt)
		VALUES (trim(name), trim(email), password_hash, password_salt)
		RETURNING id INTO user_account_id;
	RETURN QUERY SELECT
		user_account.id,
		user_account.name,
		user_account.email,
		user_account.password_hash,
		user_account.password_salt,
		user_account.receive_reply_email_notifications,
		user_account.receive_reply_desktop_notifications,
		user_account.last_new_reply_ack,
		user_account.last_new_reply_desktop_notification,
		user_account.date_created,
		user_account.role,
		user_account.receive_website_updates,
		user_account.receive_suggested_readings,
		user_account.is_email_confirmed
		FROM user_account_api.user_account WHERE id = user_account_id;
END;
$$;


ALTER FUNCTION user_account_api.create_user_account(name text, email text, password_hash bytea, password_salt bytea) OWNER TO postgres;

--
-- Name: find_user_account(text); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION find_user_account(email text) RETURNS SETOF user_account
    LANGUAGE sql
    AS $$
	SELECT
		user_account.id,
		user_account.name,
		user_account.email,
		user_account.password_hash,
		user_account.password_salt,
		user_account.receive_reply_email_notifications,
		user_account.receive_reply_desktop_notifications,
		user_account.last_new_reply_ack,
		user_account.last_new_reply_desktop_notification,
		user_account.date_created,
		user_account.role,
		user_account.receive_website_updates,
		user_account.receive_suggested_readings,
		user_account.is_email_confirmed
		FROM user_account_api.user_account WHERE lower(email) = lower(find_user_account.email);
$$;


ALTER FUNCTION user_account_api.find_user_account(email text) OWNER TO postgres;

--
-- Name: get_email_confirmation(uuid); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION get_email_confirmation(email_confirmation_id uuid) RETURNS SETOF core.email_confirmation
    LANGUAGE sql
    AS $$
	SELECT * FROM email_confirmation WHERE id = email_confirmation_id;
$$;


ALTER FUNCTION user_account_api.get_email_confirmation(email_confirmation_id uuid) OWNER TO postgres;

--
-- Name: get_latest_password_reset_request(uuid); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION get_latest_password_reset_request(user_account_id uuid) RETURNS SETOF core.password_reset_request
    LANGUAGE sql
    AS $$
	SELECT * FROM password_reset_request
		WHERE user_account_id = get_latest_password_reset_request.user_account_id
		ORDER BY date_created DESC
		LIMIT 1;
$$;


ALTER FUNCTION user_account_api.get_latest_password_reset_request(user_account_id uuid) OWNER TO postgres;

--
-- Name: get_latest_unconfirmed_email_confirmation(uuid); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION get_latest_unconfirmed_email_confirmation(user_account_id uuid) RETURNS SETOF core.email_confirmation
    LANGUAGE sql
    AS $$
	SELECT * FROM email_confirmation
		WHERE
			user_account_id = get_latest_unconfirmed_email_confirmation.user_account_id AND
			date_confirmed IS NULL
		ORDER BY date_created DESC
		LIMIT 1;
$$;


ALTER FUNCTION user_account_api.get_latest_unconfirmed_email_confirmation(user_account_id uuid) OWNER TO postgres;

--
-- Name: get_latest_unread_reply(uuid); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION get_latest_unread_reply(user_account_id uuid) RETURNS SETOF article_api.user_comment
    LANGUAGE sql
    AS $$
	SELECT reply.* FROM article_api.user_comment reply
		JOIN comment parent ON reply.parent_comment_id = parent.id AND reply.user_account_id != parent.user_account_id
		JOIN user_account ON parent.user_account_id = user_account.id
		WHERE user_account.id = get_latest_unread_reply.user_account_id AND reply.date_read IS NULL
		ORDER BY reply.date_created DESC
		LIMIT 1;
$$;


ALTER FUNCTION user_account_api.get_latest_unread_reply(user_account_id uuid) OWNER TO postgres;

--
-- Name: get_password_reset_request(uuid); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION get_password_reset_request(password_reset_request_id uuid) RETURNS SETOF core.password_reset_request
    LANGUAGE sql
    AS $$
	SELECT * FROM password_reset_request WHERE id = password_reset_request_id;
$$;


ALTER FUNCTION user_account_api.get_password_reset_request(password_reset_request_id uuid) OWNER TO postgres;

--
-- Name: get_user_account(uuid); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION get_user_account(user_account_id uuid) RETURNS SETOF user_account
    LANGUAGE sql
    AS $$
	SELECT
		user_account.id,
		user_account.name,
		user_account.email,
		user_account.password_hash,
		user_account.password_salt,
		user_account.receive_reply_email_notifications,
		user_account.receive_reply_desktop_notifications,
		user_account.last_new_reply_ack,
		user_account.last_new_reply_desktop_notification,
		user_account.date_created,
		user_account.role,
		user_account.receive_website_updates,
		user_account.receive_suggested_readings,
		user_account.is_email_confirmed
		FROM user_account_api.user_account WHERE id = user_account_id;
$$;


ALTER FUNCTION user_account_api.get_user_account(user_account_id uuid) OWNER TO postgres;

--
-- Name: is_email_address_confirmed(uuid, text); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION is_email_address_confirmed(user_account_id uuid, email text) RETURNS boolean
    LANGUAGE sql
    AS $$
	SELECT EXISTS(
		SELECT 1 FROM email_confirmation WHERE
			user_account_id = is_email_address_confirmed.user_account_id AND
			lower(email_address) = lower(email) AND
			date_confirmed IS NOT NULL
	);
$$;


ALTER FUNCTION user_account_api.is_email_address_confirmed(user_account_id uuid, email text) OWNER TO postgres;

--
-- Name: list_user_accounts(); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION list_user_accounts() RETURNS SETOF user_account
    LANGUAGE sql
    AS $$
	SELECT
		id,
		name,
		email,
		password_hash,
		password_salt,
		receive_reply_email_notifications,
		receive_reply_desktop_notifications,
		last_new_reply_ack,
		last_new_reply_desktop_notification,
		date_created,
		role,
		receive_website_updates,
		receive_suggested_readings,
		is_email_confirmed
		FROM user_account_api.user_account;
$$;


ALTER FUNCTION user_account_api.list_user_accounts() OWNER TO postgres;

--
-- Name: record_new_reply_desktop_notification(uuid); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION record_new_reply_desktop_notification(user_account_id uuid) RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE user_account SET last_new_reply_desktop_notification = utc_now() WHERE id = user_account_id;
$$;


ALTER FUNCTION user_account_api.record_new_reply_desktop_notification(user_account_id uuid) OWNER TO postgres;

--
-- Name: update_contact_preferences(uuid, boolean, boolean); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION update_contact_preferences(user_account_id uuid, receive_website_updates boolean, receive_suggested_readings boolean) RETURNS SETOF user_account
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE user_account SET
			receive_website_updates = update_contact_preferences.receive_website_updates,
			receive_suggested_readings = update_contact_preferences.receive_suggested_readings
		WHERE id = user_account_id;
	RETURN QUERY SELECT
		user_account.id,
		user_account.name,
		user_account.email,
		user_account.password_hash,
		user_account.password_salt,
		user_account.receive_reply_email_notifications,
		user_account.receive_reply_desktop_notifications,
		user_account.last_new_reply_ack,
		user_account.last_new_reply_desktop_notification,
		user_account.date_created,
		user_account.role,
		user_account.receive_website_updates,
		user_account.receive_suggested_readings,
		user_account.is_email_confirmed
		FROM user_account_api.user_account WHERE id = user_account_id;
END;
$$;


ALTER FUNCTION user_account_api.update_contact_preferences(user_account_id uuid, receive_website_updates boolean, receive_suggested_readings boolean) OWNER TO postgres;

--
-- Name: update_notification_preferences(uuid, boolean, boolean); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION update_notification_preferences(user_account_id uuid, receive_reply_email_notifications boolean, receive_reply_desktop_notifications boolean) RETURNS SETOF user_account
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE user_account SET
			receive_reply_email_notifications = update_notification_preferences.receive_reply_email_notifications,
			receive_reply_desktop_notifications = update_notification_preferences.receive_reply_desktop_notifications
		WHERE id = user_account_id;
	RETURN QUERY SELECT
		user_account.id,
		user_account.name,
		user_account.email,
		user_account.password_hash,
		user_account.password_salt,
		user_account.receive_reply_email_notifications,
		user_account.receive_reply_desktop_notifications,
		user_account.last_new_reply_ack,
		user_account.last_new_reply_desktop_notification,
		user_account.date_created,
		user_account.role,
		user_account.receive_website_updates,
		user_account.receive_suggested_readings,
		user_account.is_email_confirmed
		FROM user_account_api.user_account WHERE id = user_account_id;
END;
$$;


ALTER FUNCTION user_account_api.update_notification_preferences(user_account_id uuid, receive_reply_email_notifications boolean, receive_reply_desktop_notifications boolean) OWNER TO postgres;

SET search_path = article_api, pg_catalog;

--
-- Name: user_article_read; Type: VIEW; Schema: article_api; Owner: postgres
--

CREATE VIEW user_article_read AS
 SELECT user_article_progress.words_read,
    user_article_progress.date_created,
    user_article_progress.last_modified,
    user_article_progress.percent_complete,
    user_article_progress.user_account_id,
    user_article_progress.article_id
   FROM user_article_progress
  WHERE user_article_progress.is_read;


ALTER TABLE user_article_read OWNER TO postgres;

--
-- Name: article_score; Type: VIEW; Schema: article_api; Owner: postgres
--

CREATE VIEW article_score AS
 SELECT article.id AS article_id,
    (COALESCE(comments.score, (0)::bigint) + COALESCE(reads.score, (0)::bigint)) AS score
   FROM ((core.article
     LEFT JOIN ( SELECT sum(
                CASE
                    WHEN (comment.age < '36:00:00'::interval) THEN 200
                    WHEN (comment.age < '72:00:00'::interval) THEN 150
                    WHEN (comment.age < '7 days'::interval) THEN 100
                    WHEN (comment.age < '14 days'::interval) THEN 50
                    WHEN (comment.age < '1 mon'::interval) THEN 5
                    ELSE 1
                END) AS score,
            comment.article_id
           FROM ( SELECT comment_1.article_id,
                    (core.utc_now() - comment_1.date_created) AS age
                   FROM core.comment comment_1) comment
          GROUP BY comment.article_id) comments ON ((comments.article_id = article.id)))
     LEFT JOIN ( SELECT sum(
                CASE
                    WHEN (read.age < '36:00:00'::interval) THEN 175
                    WHEN (read.age < '72:00:00'::interval) THEN 125
                    WHEN (read.age < '7 days'::interval) THEN 75
                    WHEN (read.age < '14 days'::interval) THEN 25
                    WHEN (read.age < '1 mon'::interval) THEN 5
                    ELSE 1
                END) AS score,
            read.article_id
           FROM ( SELECT user_article_read.article_id,
                    (core.utc_now() - user_article_read.last_modified) AS age
                   FROM user_article_read) read
          GROUP BY read.article_id) reads ON ((reads.article_id = article.id)))
  GROUP BY article.id, comments.score, reads.score;


ALTER TABLE article_score OWNER TO postgres;

SET search_path = core, pg_catalog;

--
-- Name: article_author; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE article_author (
    article_id uuid NOT NULL,
    author_id uuid NOT NULL
);


ALTER TABLE article_author OWNER TO postgres;

--
-- Name: article_tag; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE article_tag (
    article_id uuid NOT NULL,
    tag_id uuid NOT NULL
);


ALTER TABLE article_tag OWNER TO postgres;

--
-- Name: author; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE author (
    id uuid DEFAULT pgcrypto.gen_random_uuid() NOT NULL,
    name text NOT NULL,
    url text
);


ALTER TABLE author OWNER TO postgres;

--
-- Name: bulk_mailing; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE bulk_mailing (
    id uuid DEFAULT pgcrypto.gen_random_uuid() NOT NULL,
    date_sent timestamp without time zone DEFAULT utc_now() NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    list text NOT NULL,
    user_account_id uuid NOT NULL
);


ALTER TABLE bulk_mailing OWNER TO postgres;

--
-- Name: bulk_mailing_recipient; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE bulk_mailing_recipient (
    bulk_mailing_id uuid NOT NULL,
    user_account_id uuid NOT NULL,
    is_successful boolean NOT NULL
);


ALTER TABLE bulk_mailing_recipient OWNER TO postgres;

--
-- Name: tag; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE tag (
    id uuid DEFAULT pgcrypto.gen_random_uuid() NOT NULL,
    name text NOT NULL
);


ALTER TABLE tag OWNER TO postgres;

--
-- Data for Name: article; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY article (id, title, slug, source_id, date_published, date_modified, section, description, aotd_timestamp, score) FROM stdin;
\.
COPY article (id, title, slug, source_id, date_published, date_modified, section, description, aotd_timestamp, score) FROM '$$PATH$$/2457.dat';

--
-- Data for Name: article_author; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY article_author (article_id, author_id) FROM stdin;
\.
COPY article_author (article_id, author_id) FROM '$$PATH$$/2468.dat';

--
-- Data for Name: article_tag; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY article_tag (article_id, tag_id) FROM stdin;
\.
COPY article_tag (article_id, tag_id) FROM '$$PATH$$/2469.dat';

--
-- Data for Name: author; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY author (id, name, url) FROM stdin;
\.
COPY author (id, name, url) FROM '$$PATH$$/2470.dat';

--
-- Data for Name: bulk_mailing; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY bulk_mailing (id, date_sent, subject, body, list, user_account_id) FROM stdin;
\.
COPY bulk_mailing (id, date_sent, subject, body, list, user_account_id) FROM '$$PATH$$/2471.dat';

--
-- Data for Name: bulk_mailing_recipient; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY bulk_mailing_recipient (bulk_mailing_id, user_account_id, is_successful) FROM stdin;
\.
COPY bulk_mailing_recipient (bulk_mailing_id, user_account_id, is_successful) FROM '$$PATH$$/2472.dat';

--
-- Data for Name: comment; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY comment (id, date_created, text, article_id, user_account_id, parent_comment_id, date_read) FROM stdin;
\.
COPY comment (id, date_created, text, article_id, user_account_id, parent_comment_id, date_read) FROM '$$PATH$$/2458.dat';

--
-- Data for Name: email_bounce; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY email_bounce (id, date_received, address, message, bulk_mailing_id) FROM stdin;
\.
COPY email_bounce (id, date_received, address, message, bulk_mailing_id) FROM '$$PATH$$/2465.dat';

--
-- Data for Name: email_confirmation; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY email_confirmation (id, date_created, user_account_id, email_address, date_confirmed) FROM stdin;
\.
COPY email_confirmation (id, date_created, user_account_id, email_address, date_confirmed) FROM '$$PATH$$/2466.dat';

--
-- Data for Name: page; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY page (id, article_id, number, word_count, readable_word_count, url) FROM stdin;
\.
COPY page (id, article_id, number, word_count, readable_word_count, url) FROM '$$PATH$$/2460.dat';

--
-- Data for Name: password_reset_request; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY password_reset_request (id, date_created, user_account_id, email_address, date_completed) FROM stdin;
\.
COPY password_reset_request (id, date_created, user_account_id, email_address, date_completed) FROM '$$PATH$$/2467.dat';

--
-- Data for Name: source; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY source (id, name, url, hostname, slug, parser) FROM stdin;
\.
COPY source (id, name, url, hostname, slug, parser) FROM '$$PATH$$/2461.dat';

--
-- Data for Name: source_rule; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY source_rule (id, hostname, path, priority, action) FROM stdin;
\.
COPY source_rule (id, hostname, path, priority, action) FROM '$$PATH$$/2464.dat';

--
-- Data for Name: star; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY star (user_account_id, article_id, date_starred) FROM stdin;
\.
COPY star (user_account_id, article_id, date_starred) FROM '$$PATH$$/2463.dat';

--
-- Data for Name: tag; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY tag (id, name) FROM stdin;
\.
COPY tag (id, name) FROM '$$PATH$$/2473.dat';

--
-- Data for Name: user_account; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY user_account (id, name, email, password_hash, password_salt, receive_reply_email_notifications, receive_reply_desktop_notifications, last_new_reply_ack, last_new_reply_desktop_notification, date_created, role, receive_website_updates, receive_suggested_readings) FROM stdin;
\.
COPY user_account (id, name, email, password_hash, password_salt, receive_reply_email_notifications, receive_reply_desktop_notifications, last_new_reply_ack, last_new_reply_desktop_notification, date_created, role, receive_website_updates, receive_suggested_readings) FROM '$$PATH$$/2459.dat';

--
-- Data for Name: user_page; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY user_page (id, page_id, user_account_id, date_created, last_modified, read_state, words_read) FROM stdin;
\.
COPY user_page (id, page_id, user_account_id, date_created, last_modified, read_state, words_read) FROM '$$PATH$$/2462.dat';

--
-- Name: article_author article_author_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY article_author
    ADD CONSTRAINT article_author_pkey PRIMARY KEY (article_id, author_id);


--
-- Name: article article_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY article
    ADD CONSTRAINT article_pkey PRIMARY KEY (id);


--
-- Name: article article_slug_key; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY article
    ADD CONSTRAINT article_slug_key UNIQUE (slug);


--
-- Name: article_tag article_tag_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY article_tag
    ADD CONSTRAINT article_tag_pkey PRIMARY KEY (article_id, tag_id);


--
-- Name: author author_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY author
    ADD CONSTRAINT author_pkey PRIMARY KEY (id);


--
-- Name: bulk_mailing bulk_mailing_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY bulk_mailing
    ADD CONSTRAINT bulk_mailing_pkey PRIMARY KEY (id);


--
-- Name: bulk_mailing_recipient bulk_mailing_recipient_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY bulk_mailing_recipient
    ADD CONSTRAINT bulk_mailing_recipient_pkey PRIMARY KEY (bulk_mailing_id, user_account_id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: email_bounce email_bounce_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY email_bounce
    ADD CONSTRAINT email_bounce_pkey PRIMARY KEY (id);


--
-- Name: email_confirmation email_confirmation_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY email_confirmation
    ADD CONSTRAINT email_confirmation_pkey PRIMARY KEY (id);


--
-- Name: page page_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY page
    ADD CONSTRAINT page_pkey PRIMARY KEY (id);


--
-- Name: password_reset_request password_reset_request_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY password_reset_request
    ADD CONSTRAINT password_reset_request_pkey PRIMARY KEY (id);


--
-- Name: source source_hostname_key; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY source
    ADD CONSTRAINT source_hostname_key UNIQUE (hostname);


--
-- Name: source source_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY source
    ADD CONSTRAINT source_pkey PRIMARY KEY (id);


--
-- Name: source_rule source_rule_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY source_rule
    ADD CONSTRAINT source_rule_pkey PRIMARY KEY (id);


--
-- Name: source source_slug_key; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY source
    ADD CONSTRAINT source_slug_key UNIQUE (slug);


--
-- Name: star star_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY star
    ADD CONSTRAINT star_pkey PRIMARY KEY (user_account_id, article_id);


--
-- Name: tag tag_name_key; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY tag
    ADD CONSTRAINT tag_name_key UNIQUE (name);


--
-- Name: tag tag_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY tag
    ADD CONSTRAINT tag_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY user_account
    ADD CONSTRAINT user_account_pkey PRIMARY KEY (id);


--
-- Name: user_page user_page_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY user_page
    ADD CONSTRAINT user_page_pkey PRIMARY KEY (id);


--
-- Name: user_account_email_key; Type: INDEX; Schema: core; Owner: postgres
--

CREATE UNIQUE INDEX user_account_email_key ON user_account USING btree (lower((email)::text));


--
-- Name: user_account_name_key; Type: INDEX; Schema: core; Owner: postgres
--

CREATE UNIQUE INDEX user_account_name_key ON user_account USING btree (lower((name)::text));


SET search_path = article_api, pg_catalog;

--
-- Name: article _RETURN; Type: RULE; Schema: article_api; Owner: postgres
--

CREATE RULE "_RETURN" AS
    ON SELECT TO article DO INSTEAD  SELECT article.id,
    article.title,
    article.slug,
    article.source_id,
    source.name AS source,
    article.date_published,
    article.date_modified,
    article.section,
    article.description,
    article.aotd_timestamp,
    article.score,
    article_pages.urls[1] AS url,
    COALESCE(authors.names, '{}'::text[]) AS authors,
    COALESCE(tags.names, '{}'::text[]) AS tags,
    article_pages.word_count,
    article_pages.readable_word_count,
    article_pages.count AS page_count,
    COALESCE(comments.count, (0)::bigint) AS comment_count,
    comments.latest_date AS latest_comment_date,
    COALESCE(reads.count, (0)::bigint) AS read_count,
    reads.latest_date AS latest_read_date
   FROM ((((((core.article
     JOIN article_pages ON ((article_pages.article_id = article.id)))
     JOIN core.source ON ((source.id = article.source_id)))
     LEFT JOIN ( SELECT array_agg(author.name) AS names,
            article_author.article_id
           FROM (core.author
             JOIN core.article_author ON ((article_author.author_id = author.id)))
          GROUP BY article_author.article_id) authors ON ((authors.article_id = article.id)))
     LEFT JOIN ( SELECT array_agg(tag.name) AS names,
            article_tag.article_id
           FROM (core.tag
             JOIN core.article_tag ON ((article_tag.tag_id = tag.id)))
          GROUP BY article_tag.article_id) tags ON ((tags.article_id = article.id)))
     LEFT JOIN ( SELECT count(*) AS count,
            max(comment.date_created) AS latest_date,
            comment.article_id
           FROM core.comment
          GROUP BY comment.article_id) comments ON ((comments.article_id = article.id)))
     LEFT JOIN ( SELECT count(*) AS count,
            max(user_article_read.last_modified) AS latest_date,
            user_article_read.article_id
           FROM user_article_read
          GROUP BY user_article_read.article_id) reads ON ((reads.article_id = article.id)))
  GROUP BY article.id, source.id, article_pages.urls, article_pages.word_count, article_pages.readable_word_count, article_pages.count, authors.names, tags.names, comments.count, comments.latest_date, reads.count, reads.latest_date;


SET search_path = core, pg_catalog;

--
-- Name: article_author article_author_article_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY article_author
    ADD CONSTRAINT article_author_article_id_fkey FOREIGN KEY (article_id) REFERENCES article(id);


--
-- Name: article_author article_author_author_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY article_author
    ADD CONSTRAINT article_author_author_id_fkey FOREIGN KEY (author_id) REFERENCES author(id);


--
-- Name: article article_source_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY article
    ADD CONSTRAINT article_source_id_fkey FOREIGN KEY (source_id) REFERENCES source(id);


--
-- Name: article_tag article_tag_article_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY article_tag
    ADD CONSTRAINT article_tag_article_id_fkey FOREIGN KEY (article_id) REFERENCES article(id);


--
-- Name: article_tag article_tag_tag_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY article_tag
    ADD CONSTRAINT article_tag_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES tag(id);


--
-- Name: bulk_mailing_recipient bulk_mailing_recipient_bulk_mailing_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY bulk_mailing_recipient
    ADD CONSTRAINT bulk_mailing_recipient_bulk_mailing_id_fkey FOREIGN KEY (bulk_mailing_id) REFERENCES bulk_mailing(id);


--
-- Name: bulk_mailing_recipient bulk_mailing_recipient_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY bulk_mailing_recipient
    ADD CONSTRAINT bulk_mailing_recipient_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES user_account(id);


--
-- Name: bulk_mailing bulk_mailing_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY bulk_mailing
    ADD CONSTRAINT bulk_mailing_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES user_account(id);


--
-- Name: comment comment_article_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY comment
    ADD CONSTRAINT comment_article_id_fkey FOREIGN KEY (article_id) REFERENCES article(id);


--
-- Name: comment comment_parent_comment_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY comment
    ADD CONSTRAINT comment_parent_comment_id_fkey FOREIGN KEY (parent_comment_id) REFERENCES comment(id);


--
-- Name: comment comment_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY comment
    ADD CONSTRAINT comment_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES user_account(id);


--
-- Name: email_bounce email_bounce_bulk_mailing_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY email_bounce
    ADD CONSTRAINT email_bounce_bulk_mailing_id_fkey FOREIGN KEY (bulk_mailing_id) REFERENCES bulk_mailing(id);


--
-- Name: email_confirmation email_confirmation_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY email_confirmation
    ADD CONSTRAINT email_confirmation_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES user_account(id);


--
-- Name: page page_article_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY page
    ADD CONSTRAINT page_article_id_fkey FOREIGN KEY (article_id) REFERENCES article(id);


--
-- Name: password_reset_request password_reset_request_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY password_reset_request
    ADD CONSTRAINT password_reset_request_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES user_account(id);


--
-- Name: star star_article_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY star
    ADD CONSTRAINT star_article_id_fkey FOREIGN KEY (article_id) REFERENCES article(id);


--
-- Name: star star_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY star
    ADD CONSTRAINT star_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES user_account(id);


--
-- Name: user_page user_page_page_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY user_page
    ADD CONSTRAINT user_page_page_id_fkey FOREIGN KEY (page_id) REFERENCES page(id);


--
-- Name: user_page user_page_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY user_page
    ADD CONSTRAINT user_page_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES user_account(id);


--
-- PostgreSQL database dump complete
--

