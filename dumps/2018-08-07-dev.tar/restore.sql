--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.8
-- Dumped by pg_dump version 9.6.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY core.user_page DROP CONSTRAINT user_page_user_account_id_fkey;
ALTER TABLE ONLY core.user_page DROP CONSTRAINT user_page_page_id_fkey;
ALTER TABLE ONLY core.user_account DROP CONSTRAINT user_account_time_zone_id_fkey;
ALTER TABLE ONLY core.star DROP CONSTRAINT star_user_account_id_fkey;
ALTER TABLE ONLY core.star DROP CONSTRAINT star_article_id_fkey;
ALTER TABLE ONLY core.password_reset_request DROP CONSTRAINT password_reset_request_user_account_id_fkey;
ALTER TABLE ONLY core.page DROP CONSTRAINT page_article_id_fkey;
ALTER TABLE ONLY core.email_share DROP CONSTRAINT email_share_user_account_id_fkey;
ALTER TABLE ONLY core.email_share_recipient DROP CONSTRAINT email_share_recipient_user_account_id_fkey;
ALTER TABLE ONLY core.email_share_recipient DROP CONSTRAINT email_share_recipient_email_share_id_fkey;
ALTER TABLE ONLY core.email_share DROP CONSTRAINT email_share_article_id_fkey;
ALTER TABLE ONLY core.email_confirmation DROP CONSTRAINT email_confirmation_user_account_id_fkey;
ALTER TABLE ONLY core.email_bounce DROP CONSTRAINT email_bounce_bulk_mailing_id_fkey;
ALTER TABLE ONLY core.comment DROP CONSTRAINT comment_user_account_id_fkey;
ALTER TABLE ONLY core.comment DROP CONSTRAINT comment_parent_comment_id_fkey;
ALTER TABLE ONLY core.comment DROP CONSTRAINT comment_article_id_fkey;
ALTER TABLE ONLY core.challenge_response DROP CONSTRAINT challenge_response_user_account_id_fkey;
ALTER TABLE ONLY core.challenge_response DROP CONSTRAINT challenge_response_time_zone_id_fkey;
ALTER TABLE ONLY core.challenge_response DROP CONSTRAINT challenge_response_challenge_id_fkey;
ALTER TABLE ONLY core.challenge_award DROP CONSTRAINT challenge_award_user_account_id_fkey;
ALTER TABLE ONLY core.challenge_award DROP CONSTRAINT challenge_award_challenge_id_fkey;
ALTER TABLE ONLY core.bulk_mailing DROP CONSTRAINT bulk_mailing_user_account_id_fkey;
ALTER TABLE ONLY core.bulk_mailing_recipient DROP CONSTRAINT bulk_mailing_recipient_user_account_id_fkey;
ALTER TABLE ONLY core.bulk_mailing_recipient DROP CONSTRAINT bulk_mailing_recipient_bulk_mailing_id_fkey;
ALTER TABLE ONLY core.article_tag DROP CONSTRAINT article_tag_tag_id_fkey;
ALTER TABLE ONLY core.article_tag DROP CONSTRAINT article_tag_article_id_fkey;
ALTER TABLE ONLY core.article DROP CONSTRAINT article_source_id_fkey;
ALTER TABLE ONLY core.article_author DROP CONSTRAINT article_author_author_id_fkey;
ALTER TABLE ONLY core.article_author DROP CONSTRAINT article_author_article_id_fkey;
DROP RULE "_RETURN" ON challenge_api.challenge;
DROP RULE "_RETURN" ON article_api.article;
DROP INDEX core.user_account_name_key;
DROP INDEX core.user_account_email_key;
DROP INDEX core.page_article_id_idx;
DROP INDEX challenge_api.challenge_contender_challenge_id_name_key;
ALTER TABLE ONLY core.user_page DROP CONSTRAINT user_page_pkey;
ALTER TABLE ONLY core.user_account DROP CONSTRAINT user_account_pkey;
ALTER TABLE ONLY core.time_zone DROP CONSTRAINT time_zone_pkey;
ALTER TABLE ONLY core.time_zone DROP CONSTRAINT time_zone_name_territory_key;
ALTER TABLE ONLY core.tag DROP CONSTRAINT tag_pkey;
ALTER TABLE ONLY core.tag DROP CONSTRAINT tag_name_key;
ALTER TABLE ONLY core.star DROP CONSTRAINT star_pkey;
ALTER TABLE ONLY core.source DROP CONSTRAINT source_slug_key;
ALTER TABLE ONLY core.source_rule DROP CONSTRAINT source_rule_pkey;
ALTER TABLE ONLY core.source DROP CONSTRAINT source_pkey;
ALTER TABLE ONLY core.source DROP CONSTRAINT source_hostname_key;
ALTER TABLE ONLY core.password_reset_request DROP CONSTRAINT password_reset_request_pkey;
ALTER TABLE ONLY core.page DROP CONSTRAINT page_pkey;
ALTER TABLE ONLY core.email_share_recipient DROP CONSTRAINT email_share_recipient_pkey;
ALTER TABLE ONLY core.email_share DROP CONSTRAINT email_share_pkey;
ALTER TABLE ONLY core.email_confirmation DROP CONSTRAINT email_confirmation_pkey;
ALTER TABLE ONLY core.email_bounce DROP CONSTRAINT email_bounce_pkey;
ALTER TABLE ONLY core.comment DROP CONSTRAINT comment_pkey;
ALTER TABLE ONLY core.challenge_response DROP CONSTRAINT challenge_response_pkey;
ALTER TABLE ONLY core.challenge DROP CONSTRAINT challenge_pkey;
ALTER TABLE ONLY core.challenge_award DROP CONSTRAINT challenge_award_pkey;
ALTER TABLE ONLY core.bulk_mailing_recipient DROP CONSTRAINT bulk_mailing_recipient_pkey;
ALTER TABLE ONLY core.bulk_mailing DROP CONSTRAINT bulk_mailing_pkey;
ALTER TABLE ONLY core.author DROP CONSTRAINT author_pkey;
ALTER TABLE ONLY core.article_tag DROP CONSTRAINT article_tag_pkey;
ALTER TABLE ONLY core.article DROP CONSTRAINT article_slug_key;
ALTER TABLE ONLY core.article DROP CONSTRAINT article_pkey;
ALTER TABLE ONLY core.article_author DROP CONSTRAINT article_author_pkey;
ALTER TABLE core.user_page ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.user_account ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.tag ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.source_rule ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.source ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.password_reset_request ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.page ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.email_share_recipient ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.email_share ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.email_confirmation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.email_bounce ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.comment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.challenge_response ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.challenge_award ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.challenge ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.bulk_mailing ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.author ALTER COLUMN id DROP DEFAULT;
ALTER TABLE core.article ALTER COLUMN id DROP DEFAULT;
DROP TABLE id_migration.user_account;
DROP SEQUENCE core.user_page_id_seq;
DROP SEQUENCE core.user_account_id_seq;
DROP SEQUENCE core.tag_id_seq;
DROP TABLE core.tag;
DROP SEQUENCE core.source_rule_id_seq;
DROP SEQUENCE core.source_id_seq;
DROP SEQUENCE core.password_reset_request_id_seq;
DROP SEQUENCE core.page_id_seq;
DROP SEQUENCE core.email_share_recipient_id_seq;
DROP TABLE core.email_share_recipient;
DROP SEQUENCE core.email_share_id_seq;
DROP TABLE core.email_share;
DROP SEQUENCE core.email_confirmation_id_seq;
DROP SEQUENCE core.email_bounce_id_seq;
DROP SEQUENCE core.comment_id_seq;
DROP SEQUENCE core.challenge_response_id_seq;
DROP SEQUENCE core.challenge_id_seq;
DROP SEQUENCE core.challenge_award_id_seq;
DROP TABLE core.bulk_mailing_recipient;
DROP SEQUENCE core.bulk_mailing_id_seq;
DROP TABLE core.bulk_mailing;
DROP SEQUENCE core.author_id_seq;
DROP TABLE core.author;
DROP TABLE core.article_tag;
DROP SEQUENCE core.article_id_seq;
DROP TABLE core.article_author;
DROP MATERIALIZED VIEW challenge_api.challenge_contender;
DROP TABLE core.challenge_award;
DROP TABLE core.challenge;
DROP VIEW challenge_api.latest_challenge_response;
DROP VIEW article_api.article_score;
DROP VIEW article_api.user_article_read;
DROP FUNCTION user_account_api.update_notification_preferences(user_account_id bigint, receive_reply_email_notifications boolean, receive_reply_desktop_notifications boolean);
DROP FUNCTION user_account_api.update_contact_preferences(user_account_id bigint, receive_website_updates boolean, receive_suggested_readings boolean);
DROP FUNCTION user_account_api.record_new_reply_desktop_notification(user_account_id bigint);
DROP FUNCTION user_account_api.list_user_accounts();
DROP FUNCTION user_account_api.list_email_confirmations(user_account_id bigint);
DROP FUNCTION user_account_api.is_email_address_confirmed(user_account_id bigint, email text);
DROP FUNCTION user_account_api.get_user_account_using_old_id(user_account_id uuid);
DROP FUNCTION user_account_api.get_user_account(user_account_id bigint);
DROP FUNCTION user_account_api.get_password_reset_request(password_reset_request_id bigint);
DROP FUNCTION user_account_api.get_latest_unread_reply(user_account_id bigint);
DROP FUNCTION user_account_api.get_latest_unconfirmed_email_confirmation(user_account_id bigint);
DROP FUNCTION user_account_api.get_latest_password_reset_request(user_account_id bigint);
DROP FUNCTION user_account_api.get_email_confirmation(email_confirmation_id bigint);
DROP FUNCTION user_account_api.find_user_account(email text);
DROP FUNCTION user_account_api.create_user_account(name text, email text, password_hash bytea, password_salt bytea);
DROP FUNCTION user_account_api.create_password_reset_request(user_account_id bigint);
DROP TABLE core.password_reset_request;
DROP FUNCTION user_account_api.create_email_confirmation(user_account_id bigint);
DROP FUNCTION user_account_api.confirm_email_address(email_confirmation_id bigint);
DROP FUNCTION user_account_api.complete_password_reset_request(password_reset_request_id bigint);
DROP FUNCTION user_account_api.change_password(user_account_id bigint, password_hash bytea, password_salt bytea);
DROP FUNCTION user_account_api.change_email_address(user_account_id bigint, email text);
DROP FUNCTION user_account_api.ack_new_reply(user_account_id bigint);
DROP FUNCTION core.local_now(time_zone_name text);
DROP FUNCTION core.get_time_zones();
DROP FUNCTION core.generate_local_to_utc_date_series(start date, stop date, day_step_count integer, time_zone_name text);
DROP FUNCTION challenge_api.get_latest_challenge_response(challenge_id bigint, user_account_id bigint);
DROP FUNCTION challenge_api.get_challenge_winners(challenge_id bigint);
DROP FUNCTION challenge_api.get_challenge_score(challenge_id bigint, user_account_id bigint);
DROP FUNCTION challenge_api.get_challenge_response_action_totals(challenge_id bigint);
DROP FUNCTION challenge_api.get_challenge_contenders(challenge_id bigint);
DROP FUNCTION challenge_api.get_active_challenges();
DROP TABLE challenge_api.challenge;
DROP FUNCTION challenge_api.create_challenge_response(challenge_id bigint, user_account_id bigint, action core.challenge_response_action, time_zone_id bigint);
DROP VIEW challenge_api.challenge_response;
DROP TABLE core.challenge_response;
DROP FUNCTION bulk_mailing_api.list_email_bounces();
DROP TABLE core.email_bounce;
DROP FUNCTION bulk_mailing_api.list_confirmation_reminder_recipients();
DROP VIEW user_account_api.user_account;
DROP TABLE core.time_zone;
DROP TABLE core.email_confirmation;
DROP FUNCTION bulk_mailing_api.list_bulk_mailings();
DROP FUNCTION bulk_mailing_api.create_bulk_mailing(subject text, body text, list text, user_account_id bigint, recipient_ids bigint[], recipient_results boolean[]);
DROP FUNCTION article_api.update_user_page(user_page_id bigint, read_state integer[]);
DROP FUNCTION article_api.unstar_article(user_account_id bigint, article_id bigint);
DROP FUNCTION article_api.star_article(user_account_id bigint, article_id bigint);
DROP FUNCTION article_api.set_aotd();
DROP FUNCTION article_api.score_articles();
DROP FUNCTION article_api.read_comment(comment_id bigint);
DROP FUNCTION article_api.list_user_hot_topics(user_account_id bigint, page_number integer, page_size integer);
DROP FUNCTION article_api.list_user_article_history(user_account_id bigint, page_number integer, page_size integer);
DROP FUNCTION article_api.list_starred_articles(user_account_id bigint, page_number integer, page_size integer);
DROP FUNCTION article_api.list_replies(user_account_id bigint, page_number integer, page_size integer);
DROP FUNCTION article_api.list_hot_topics(page_number integer, page_size integer);
DROP FUNCTION article_api.list_comments(article_id bigint);
DROP FUNCTION article_api.get_user_page(page_id bigint, user_account_id bigint);
DROP FUNCTION article_api.get_user_article(article_id bigint, user_account_id bigint);
DROP FUNCTION article_api.get_user_aotd(user_account_id bigint);
DROP FUNCTION article_api.get_source_rules();
DROP TABLE core.source_rule;
DROP FUNCTION article_api.get_page(page_id bigint);
DROP FUNCTION article_api.get_comment(comment_id bigint);
DROP FUNCTION article_api.get_aotd();
DROP FUNCTION article_api.find_user_article(slug text, user_account_id bigint);
DROP VIEW article_api.user_article;
DROP TABLE core.star;
DROP VIEW article_api.user_article_progress;
DROP VIEW article_api.article_pages;
DROP FUNCTION article_api.find_source(source_hostname text);
DROP FUNCTION article_api.find_page(url text);
DROP FUNCTION article_api.find_article(slug text);
DROP TABLE article_api.article;
DROP FUNCTION article_api.delete_user_article(article_id bigint, user_account_id bigint);
DROP FUNCTION article_api.delete_article(id bigint);
DROP FUNCTION article_api.create_user_page(page_id bigint, user_account_id bigint);
DROP TABLE core.user_page;
DROP FUNCTION article_api.create_source(name text, url text, hostname text, slug text);
DROP TABLE core.source;
DROP FUNCTION article_api.create_page(article_id bigint, number integer, word_count integer, readable_word_count integer, url text);
DROP TABLE core.page;
DROP FUNCTION article_api.create_email_share(date_sent timestamp without time zone, article_id bigint, user_account_id bigint, message text, recipient_addresses text[], recipient_ids bigint[], recipient_results boolean[]);
DROP FUNCTION article_api.create_comment(text text, article_id bigint, parent_comment_id bigint, user_account_id bigint);
DROP VIEW article_api.user_comment;
DROP TABLE core.user_account;
DROP TABLE core.comment;
DROP TABLE core.article;
DROP FUNCTION core.utc_now();
DROP FUNCTION article_api.create_article(title text, slug text, source_id bigint, date_published timestamp without time zone, date_modified timestamp without time zone, section text, description text, author_names text[], author_urls text[], tags text[]);
DROP TYPE core.user_account_role;
DROP DOMAIN core.time_zone_name;
DROP FUNCTION core.is_time_zone_name(name text);
DROP TYPE core.source_rule_action;
DROP TYPE core.challenge_response_action;
DROP TYPE article_api.user_comment_page_result;
DROP TYPE article_api.user_article_page_result;
DROP TYPE article_api.article_page_result;
DROP EXTENSION plpgsql;
DROP SCHEMA user_account_api;
DROP SCHEMA id_migration;
DROP SCHEMA core;
DROP SCHEMA challenge_api;
DROP SCHEMA bulk_mailing_api;
DROP SCHEMA article_api;
--
-- Name: article_api; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA article_api;


ALTER SCHEMA article_api OWNER TO postgres;

--
-- Name: bulk_mailing_api; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA bulk_mailing_api;


ALTER SCHEMA bulk_mailing_api OWNER TO postgres;

--
-- Name: challenge_api; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA challenge_api;


ALTER SCHEMA challenge_api OWNER TO postgres;

--
-- Name: core; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA core;


ALTER SCHEMA core OWNER TO postgres;

--
-- Name: id_migration; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA id_migration;


ALTER SCHEMA id_migration OWNER TO postgres;

--
-- Name: user_account_api; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA user_account_api;


ALTER SCHEMA user_account_api OWNER TO postgres;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: article_page_result; Type: TYPE; Schema: article_api; Owner: postgres
--

CREATE TYPE article_api.article_page_result AS (
	id bigint,
	title text,
	slug text,
	source_id bigint,
	source text,
	date_published timestamp without time zone,
	date_modified timestamp without time zone,
	section text,
	description text,
	aotd_timestamp timestamp without time zone,
	score integer,
	url text,
	authors text[],
	tags text[],
	word_count bigint,
	readable_word_count bigint,
	page_count bigint,
	comment_count bigint,
	latest_comment_date timestamp without time zone,
	read_count bigint,
	latest_read_date timestamp without time zone,
	total_count bigint
);


ALTER TYPE article_api.article_page_result OWNER TO postgres;

--
-- Name: user_article_page_result; Type: TYPE; Schema: article_api; Owner: postgres
--

CREATE TYPE article_api.user_article_page_result AS (
	id bigint,
	title text,
	slug text,
	source_id bigint,
	source text,
	date_published timestamp without time zone,
	date_modified timestamp without time zone,
	section text,
	description text,
	aotd_timestamp timestamp without time zone,
	score integer,
	url text,
	authors text[],
	tags text[],
	word_count bigint,
	readable_word_count bigint,
	page_count bigint,
	comment_count bigint,
	latest_comment_date timestamp without time zone,
	read_count bigint,
	latest_read_date timestamp without time zone,
	user_account_id bigint,
	words_read bigint,
	date_created timestamp without time zone,
	last_modified timestamp without time zone,
	percent_complete double precision,
	is_read boolean,
	date_completed timestamp without time zone,
	date_starred timestamp without time zone,
	total_count bigint
);


ALTER TYPE article_api.user_article_page_result OWNER TO postgres;

--
-- Name: user_comment_page_result; Type: TYPE; Schema: article_api; Owner: postgres
--

CREATE TYPE article_api.user_comment_page_result AS (
	id bigint,
	date_created timestamp without time zone,
	text text,
	article_id bigint,
	article_title text,
	article_slug text,
	user_account_id bigint,
	user_account text,
	parent_comment_id bigint,
	date_read timestamp without time zone,
	total_count bigint
);


ALTER TYPE article_api.user_comment_page_result OWNER TO postgres;

--
-- Name: challenge_response_action; Type: TYPE; Schema: core; Owner: postgres
--

CREATE TYPE core.challenge_response_action AS ENUM (
    'enroll',
    'decline',
    'disenroll'
);


ALTER TYPE core.challenge_response_action OWNER TO postgres;

--
-- Name: source_rule_action; Type: TYPE; Schema: core; Owner: postgres
--

CREATE TYPE core.source_rule_action AS ENUM (
    'default',
    'read',
    'ignore'
);


ALTER TYPE core.source_rule_action OWNER TO postgres;

--
-- Name: is_time_zone_name(text); Type: FUNCTION; Schema: core; Owner: postgres
--

CREATE FUNCTION core.is_time_zone_name(name text) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
	PERFORM now() AT TIME ZONE is_time_zone_name.name;
	RETURN TRUE;
EXCEPTION
	WHEN invalid_parameter_value THEN
		RETURN FALSE;
END;
$$;


ALTER FUNCTION core.is_time_zone_name(name text) OWNER TO postgres;

--
-- Name: time_zone_name; Type: DOMAIN; Schema: core; Owner: postgres
--

CREATE DOMAIN core.time_zone_name AS text
	CONSTRAINT time_zone_name_check CHECK (core.is_time_zone_name(VALUE));


ALTER DOMAIN core.time_zone_name OWNER TO postgres;

--
-- Name: user_account_role; Type: TYPE; Schema: core; Owner: postgres
--

CREATE TYPE core.user_account_role AS ENUM (
    'regular',
    'admin'
);


ALTER TYPE core.user_account_role OWNER TO postgres;

--
-- Name: create_article(text, text, bigint, timestamp without time zone, timestamp without time zone, text, text, text[], text[], text[]); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.create_article(title text, slug text, source_id bigint, date_published timestamp without time zone, date_modified timestamp without time zone, section text, description text, author_names text[], author_urls text[], tags text[]) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	article_id	 		bigint;
	current_author_url	text;
	current_author_id	bigint;
	current_tag			text;
	current_tag_id		bigint;
BEGIN
	INSERT INTO article (title, slug, source_id, date_published, date_modified, section, description)
		VALUES (title, slug, source_id, date_published, date_modified, section, description)
		RETURNING id INTO article_id;
	FOR i IN 1..coalesce(array_length(author_names, 1), 0) LOOP
		current_author_url := author_urls[i];
		SELECT id INTO current_author_id FROM author WHERE url = current_author_url;
		IF current_author_id IS NULL THEN
			INSERT INTO author (name, url) VALUES (author_names[i], current_author_url)
				RETURNING id INTO current_author_id;
		END IF;
		INSERT INTO article_author (article_id, author_id) VALUES (article_id, current_author_id);
	END LOOP;
	FOREACH current_tag IN ARRAY tags
	LOOP
		SELECT id INTO current_tag_id FROM tag WHERE name = current_tag;
		IF current_tag_id IS NULL THEN
			INSERT INTO tag (name) VALUES (current_tag) RETURNING id INTO current_tag_id;
		END IF;
		INSERT INTO article_tag (article_id, tag_id) VALUES (article_id, current_tag_id);
	END LOOP;
	RETURN article_id;
END;
$$;


ALTER FUNCTION article_api.create_article(title text, slug text, source_id bigint, date_published timestamp without time zone, date_modified timestamp without time zone, section text, description text, author_names text[], author_urls text[], tags text[]) OWNER TO postgres;

--
-- Name: utc_now(); Type: FUNCTION; Schema: core; Owner: postgres
--

CREATE FUNCTION core.utc_now() RETURNS timestamp without time zone
    LANGUAGE sql STABLE
    AS $$
	SELECT local_now('UTC');
$$;


ALTER FUNCTION core.utc_now() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: article; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.article (
    id bigint NOT NULL,
    title character varying(512) NOT NULL,
    slug character varying(256) NOT NULL,
    source_id bigint NOT NULL,
    date_published timestamp without time zone,
    date_modified timestamp without time zone,
    section character varying(256),
    description text,
    aotd_timestamp timestamp without time zone,
    score integer DEFAULT 0 NOT NULL
);


ALTER TABLE core.article OWNER TO postgres;

--
-- Name: comment; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.comment (
    id bigint NOT NULL,
    date_created timestamp without time zone DEFAULT core.utc_now() NOT NULL,
    text text NOT NULL,
    article_id bigint NOT NULL,
    user_account_id bigint NOT NULL,
    parent_comment_id bigint,
    date_read timestamp without time zone
);


ALTER TABLE core.comment OWNER TO postgres;

--
-- Name: user_account; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.user_account (
    id bigint NOT NULL,
    name character varying(30) NOT NULL,
    email character varying(256) NOT NULL,
    password_hash bytea NOT NULL,
    password_salt bytea NOT NULL,
    receive_reply_email_notifications boolean DEFAULT true NOT NULL,
    receive_reply_desktop_notifications boolean DEFAULT true NOT NULL,
    last_new_reply_ack timestamp without time zone DEFAULT core.utc_now() NOT NULL,
    last_new_reply_desktop_notification timestamp without time zone DEFAULT core.utc_now() NOT NULL,
    date_created timestamp without time zone DEFAULT core.utc_now() NOT NULL,
    role core.user_account_role DEFAULT 'regular'::core.user_account_role NOT NULL,
    receive_website_updates boolean DEFAULT true,
    receive_suggested_readings boolean DEFAULT true,
    time_zone_id bigint,
    CONSTRAINT user_account_email_valid CHECK (((email)::text ~~ '%@%'::text)),
    CONSTRAINT user_account_name_valid CHECK (((name)::text ~ similar_escape('[A-Za-z0-9\-_]+'::text, NULL::text)))
);


ALTER TABLE core.user_account OWNER TO postgres;

--
-- Name: user_comment; Type: VIEW; Schema: article_api; Owner: postgres
--

CREATE VIEW article_api.user_comment AS
 SELECT comment.id,
    comment.date_created,
    comment.text,
    comment.article_id,
    article.title AS article_title,
    article.slug AS article_slug,
    comment.user_account_id,
    user_account.name AS user_account,
    comment.parent_comment_id,
    comment.date_read
   FROM ((core.comment
     JOIN core.article ON ((comment.article_id = article.id)))
     JOIN core.user_account ON ((comment.user_account_id = user_account.id)));


ALTER TABLE article_api.user_comment OWNER TO postgres;

--
-- Name: create_comment(text, bigint, bigint, bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.create_comment(text text, article_id bigint, parent_comment_id bigint, user_account_id bigint) RETURNS SETOF article_api.user_comment
    LANGUAGE plpgsql
    AS $$
DECLARE
  comment_id bigint;
BEGIN
	INSERT INTO comment
        (text, article_id, parent_comment_id, user_account_id) VALUES
        (text, article_id, parent_comment_id, user_account_id) RETURNING id INTO comment_id;
    RETURN QUERY SELECT * FROM article_api.user_comment WHERE id = comment_id;
END;
$$;


ALTER FUNCTION article_api.create_comment(text text, article_id bigint, parent_comment_id bigint, user_account_id bigint) OWNER TO postgres;

--
-- Name: create_email_share(timestamp without time zone, bigint, bigint, text, text[], bigint[], boolean[]); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.create_email_share(date_sent timestamp without time zone, article_id bigint, user_account_id bigint, message text, recipient_addresses text[], recipient_ids bigint[], recipient_results boolean[]) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	email_share_id bigint;
BEGIN
	INSERT INTO email_share (date_sent, article_id, user_account_id, message)
		VALUES (date_sent, article_id, user_account_id, message)
		RETURNING id INTO email_share_id;
	FOR i IN 1..coalesce(array_length(recipient_addresses, 1), 0) LOOP
		INSERT INTO email_share_recipient
				(email_share_id, email_address, user_account_id, is_successful)
			VALUES (
				email_share_id,
				recipient_addresses[i],
				nullif(recipient_ids[i], 0),
				recipient_results[i]
			);
	END LOOP;
	RETURN email_share_id;
END;
$$;


ALTER FUNCTION article_api.create_email_share(date_sent timestamp without time zone, article_id bigint, user_account_id bigint, message text, recipient_addresses text[], recipient_ids bigint[], recipient_results boolean[]) OWNER TO postgres;

--
-- Name: page; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.page (
    id bigint NOT NULL,
    article_id bigint NOT NULL,
    number integer NOT NULL,
    word_count integer NOT NULL,
    readable_word_count integer NOT NULL,
    url character varying(256) NOT NULL
);


ALTER TABLE core.page OWNER TO postgres;

--
-- Name: create_page(bigint, integer, integer, integer, text); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.create_page(article_id bigint, number integer, word_count integer, readable_word_count integer, url text) RETURNS core.page
    LANGUAGE sql
    AS $$
	INSERT INTO page (article_id, number, word_count, readable_word_count, url)
		VALUES (article_id, number, word_count, readable_word_count, url)
		RETURNING *;
$$;


ALTER FUNCTION article_api.create_page(article_id bigint, number integer, word_count integer, readable_word_count integer, url text) OWNER TO postgres;

--
-- Name: source; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.source (
    id bigint NOT NULL,
    name character varying(256),
    url character varying(256) NOT NULL,
    hostname character varying(256) NOT NULL,
    slug character varying(256) NOT NULL,
    parser text
);


ALTER TABLE core.source OWNER TO postgres;

--
-- Name: create_source(text, text, text, text); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.create_source(name text, url text, hostname text, slug text) RETURNS core.source
    LANGUAGE sql
    AS $$
	INSERT INTO source (name, url, hostname, slug) VALUES (name, url, hostname, slug) RETURNING *;
$$;


ALTER FUNCTION article_api.create_source(name text, url text, hostname text, slug text) OWNER TO postgres;

--
-- Name: user_page; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.user_page (
    id bigint NOT NULL,
    page_id bigint NOT NULL,
    user_account_id bigint NOT NULL,
    date_created timestamp without time zone DEFAULT core.utc_now() NOT NULL,
    last_modified timestamp without time zone,
    read_state integer[] NOT NULL,
    words_read integer DEFAULT 0 NOT NULL,
    date_completed timestamp without time zone
);


ALTER TABLE core.user_page OWNER TO postgres;

--
-- Name: create_user_page(bigint, bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.create_user_page(page_id bigint, user_account_id bigint) RETURNS core.user_page
    LANGUAGE sql
    AS $$
	INSERT INTO user_page (page_id, user_account_id, read_state)
	VALUES (
		page_id,
		user_account_id,
		ARRAY[(SELECT -word_count FROM page WHERE id = page_id)]
	)
	RETURNING *;
$$;


ALTER FUNCTION article_api.create_user_page(page_id bigint, user_account_id bigint) OWNER TO postgres;

--
-- Name: delete_article(bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.delete_article(id bigint) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	DELETE FROM user_page WHERE page_id IN (SELECT page.id FROM page WHERE article_id = delete_article.id);
	DELETE FROM page WHERE article_id = delete_article.id;
	DELETE FROM article_author WHERE article_id = delete_article.id;
	DELETE FROM article_tag WHERE article_id = delete_article.id;
	DELETE FROM article WHERE article.id = delete_article.id;
END;
$$;


ALTER FUNCTION article_api.delete_article(id bigint) OWNER TO postgres;

--
-- Name: delete_user_article(bigint, bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.delete_user_article(article_id bigint, user_account_id bigint) RETURNS void
    LANGUAGE sql
    AS $$
	DELETE FROM user_page
	WHERE (
		page_id IN (
			SELECT id
			FROM page
			WHERE page.article_id = delete_user_article.article_id
		) AND
		user_page.user_account_id = delete_user_article.user_account_id
	);
$$;


ALTER FUNCTION article_api.delete_user_article(article_id bigint, user_account_id bigint) OWNER TO postgres;

--
-- Name: article; Type: TABLE; Schema: article_api; Owner: postgres
--

CREATE TABLE article_api.article (
    id bigint,
    title character varying(512),
    slug character varying(256),
    source_id bigint,
    source character varying(256),
    date_published timestamp without time zone,
    date_modified timestamp without time zone,
    section character varying(256),
    description text,
    aotd_timestamp timestamp without time zone,
    score integer,
    url character varying,
    authors text[],
    tags text[],
    word_count bigint,
    readable_word_count bigint,
    page_count bigint,
    comment_count bigint,
    latest_comment_date timestamp without time zone,
    read_count bigint,
    latest_read_date timestamp without time zone
);

ALTER TABLE ONLY article_api.article REPLICA IDENTITY NOTHING;


ALTER TABLE article_api.article OWNER TO postgres;

--
-- Name: find_article(text); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.find_article(slug text) RETURNS SETOF article_api.article
    LANGUAGE sql
    AS $$
	SELECT
		id,
		title,
		slug,
		source_id,
		source,
		date_published,
		date_modified,
		section,
		description,
		aotd_timestamp,
		score,
		url,
		authors,
		tags,
		word_count,
		readable_word_count,
		page_count,
		comment_count,
		latest_comment_date,
		read_count,
		latest_read_date
	FROM article_api.article
	WHERE slug = find_article.slug;
$$;


ALTER FUNCTION article_api.find_article(slug text) OWNER TO postgres;

--
-- Name: find_page(text); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.find_page(url text) RETURNS SETOF core.page
    LANGUAGE sql
    AS $$
	SELECT * FROM page WHERE url = find_page.url;
$$;


ALTER FUNCTION article_api.find_page(url text) OWNER TO postgres;

--
-- Name: find_source(text); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.find_source(source_hostname text) RETURNS SETOF core.source
    LANGUAGE sql
    AS $$
	SELECT * FROM source WHERE hostname = source_hostname;
$$;


ALTER FUNCTION article_api.find_source(source_hostname text) OWNER TO postgres;

--
-- Name: article_pages; Type: VIEW; Schema: article_api; Owner: postgres
--

CREATE VIEW article_api.article_pages AS
 SELECT array_agg(page.url ORDER BY page.number) AS urls,
    count(*) AS count,
    sum(page.word_count) AS word_count,
    sum(page.readable_word_count) AS readable_word_count,
    page.article_id
   FROM core.page
  GROUP BY page.article_id;


ALTER TABLE article_api.article_pages OWNER TO postgres;

--
-- Name: user_article_progress; Type: VIEW; Schema: article_api; Owner: postgres
--

CREATE VIEW article_api.user_article_progress AS
 WITH user_article_pages AS (
         SELECT sum(user_page.words_read) AS words_read,
            min(user_page.date_created) AS date_created,
            max(user_page.last_modified) AS last_modified,
            max(user_page.date_completed) AS date_completed,
            user_page.user_account_id,
            page.article_id
           FROM (core.user_page
             JOIN core.page ON ((page.id = user_page.page_id)))
          GROUP BY user_page.user_account_id, page.article_id
        )
 SELECT user_article_progress.words_read,
    user_article_progress.date_created,
    user_article_progress.last_modified,
    user_article_progress.percent_complete,
    (user_article_progress.percent_complete >= (90)::double precision) AS is_read,
        CASE
            WHEN (user_article_progress.percent_complete >= (90)::double precision) THEN user_article_progress.date_completed
            ELSE NULL::timestamp without time zone
        END AS date_completed,
    user_article_progress.user_account_id,
    user_article_progress.article_id
   FROM ( SELECT user_article_pages.words_read,
            user_article_pages.date_created,
            user_article_pages.last_modified,
            LEAST((((user_article_pages.words_read)::double precision / (article_pages.readable_word_count)::double precision) * (100)::double precision), (100)::double precision) AS percent_complete,
            user_article_pages.date_completed,
            user_article_pages.user_account_id,
            user_article_pages.article_id
           FROM (user_article_pages
             JOIN article_api.article_pages ON ((article_pages.article_id = user_article_pages.article_id)))) user_article_progress
  GROUP BY user_article_progress.words_read, user_article_progress.date_created, user_article_progress.last_modified, user_article_progress.percent_complete, user_article_progress.date_completed, user_article_progress.user_account_id, user_article_progress.article_id;


ALTER TABLE article_api.user_article_progress OWNER TO postgres;

--
-- Name: star; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.star (
    user_account_id bigint NOT NULL,
    article_id bigint NOT NULL,
    date_starred timestamp without time zone DEFAULT core.utc_now() NOT NULL
);


ALTER TABLE core.star OWNER TO postgres;

--
-- Name: user_article; Type: VIEW; Schema: article_api; Owner: postgres
--

CREATE VIEW article_api.user_article AS
 SELECT article.id,
    article.title,
    article.slug,
    article.source_id,
    article.source,
    article.date_published,
    article.date_modified,
    article.section,
    article.description,
    article.aotd_timestamp,
    article.score,
    article.url,
    article.authors,
    article.tags,
    article.word_count,
    article.readable_word_count,
    article.page_count,
    article.comment_count,
    article.latest_comment_date,
    article.read_count,
    article.latest_read_date,
    user_account.id AS user_account_id,
    COALESCE(user_article_progress.words_read, (0)::bigint) AS words_read,
    user_article_progress.date_created,
    user_article_progress.last_modified,
    COALESCE(user_article_progress.percent_complete, (0)::double precision) AS percent_complete,
    COALESCE(user_article_progress.is_read, false) AS is_read,
    user_article_progress.date_completed,
    star.date_starred
   FROM (((article_api.article
     CROSS JOIN core.user_account)
     LEFT JOIN article_api.user_article_progress ON (((user_article_progress.user_account_id = user_account.id) AND (user_article_progress.article_id = article.id))))
     LEFT JOIN core.star ON (((star.user_account_id = user_account.id) AND (star.article_id = article.id))))
  GROUP BY article.id, article.title, article.slug, article.source_id, article.source, article.date_published, article.date_modified, article.section, article.description, article.aotd_timestamp, article.score, article.url, article.authors, article.tags, article.word_count, article.readable_word_count, article.page_count, article.comment_count, article.latest_comment_date, article.read_count, article.latest_read_date, user_account.id, user_article_progress.words_read, user_article_progress.date_created, user_article_progress.last_modified, user_article_progress.percent_complete, user_article_progress.is_read, user_article_progress.date_completed, star.date_starred;


ALTER TABLE article_api.user_article OWNER TO postgres;

--
-- Name: find_user_article(text, bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.find_user_article(slug text, user_account_id bigint) RETURNS SETOF article_api.user_article
    LANGUAGE sql
    AS $$
	SELECT *
	FROM article_api.user_article
	WHERE
		slug = find_user_article.slug AND
		user_account_id = find_user_article.user_account_id;
$$;


ALTER FUNCTION article_api.find_user_article(slug text, user_account_id bigint) OWNER TO postgres;

--
-- Name: get_aotd(); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.get_aotd() RETURNS SETOF article_api.article
    LANGUAGE sql
    AS $$
	SELECT
		id,
		title,
		slug,
		source_id,
		source,
		date_published,
		date_modified,
		section,
		description,
		aotd_timestamp,
		score,
		url,
		authors,
		tags,
		word_count,
		readable_word_count,
		page_count,
		comment_count,
		latest_comment_date,
		read_count,
		latest_read_date
	FROM article_api.article
	WHERE id = (
		SELECT id
		FROM core.article
		ORDER BY core.article.aotd_timestamp DESC NULLS LAST
		LIMIT 1
	);
$$;


ALTER FUNCTION article_api.get_aotd() OWNER TO postgres;

--
-- Name: get_comment(bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.get_comment(comment_id bigint) RETURNS SETOF article_api.user_comment
    LANGUAGE sql
    AS $$
	SELECT * FROM article_api.user_comment WHERE id = comment_id;
$$;


ALTER FUNCTION article_api.get_comment(comment_id bigint) OWNER TO postgres;

--
-- Name: get_page(bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.get_page(page_id bigint) RETURNS SETOF core.page
    LANGUAGE sql
    AS $$
	SELECT * FROM page WHERE id = page_id;
$$;


ALTER FUNCTION article_api.get_page(page_id bigint) OWNER TO postgres;

--
-- Name: source_rule; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.source_rule (
    id bigint NOT NULL,
    hostname character varying(256) NOT NULL,
    path character varying(256) NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    action core.source_rule_action NOT NULL
);


ALTER TABLE core.source_rule OWNER TO postgres;

--
-- Name: get_source_rules(); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.get_source_rules() RETURNS SETOF core.source_rule
    LANGUAGE sql
    AS $$
	SELECT * FROM source_rule;
$$;


ALTER FUNCTION article_api.get_source_rules() OWNER TO postgres;

--
-- Name: get_user_aotd(bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.get_user_aotd(user_account_id bigint) RETURNS SETOF article_api.user_article
    LANGUAGE sql
    AS $$
	SELECT *
	FROM article_api.user_article
	WHERE
		id = (
			SELECT id
			FROM core.article
			ORDER BY core.article.aotd_timestamp DESC NULLS LAST
			LIMIT 1
		) AND
		user_account_id = get_user_aotd.user_account_id;
$$;


ALTER FUNCTION article_api.get_user_aotd(user_account_id bigint) OWNER TO postgres;

--
-- Name: get_user_article(bigint, bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.get_user_article(article_id bigint, user_account_id bigint) RETURNS SETOF article_api.user_article
    LANGUAGE sql
    AS $$
	SELECT *
	FROM article_api.user_article
	WHERE
		id = article_id AND
		user_account_id = get_user_article.user_account_id;
$$;


ALTER FUNCTION article_api.get_user_article(article_id bigint, user_account_id bigint) OWNER TO postgres;

--
-- Name: get_user_page(bigint, bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.get_user_page(page_id bigint, user_account_id bigint) RETURNS SETOF core.user_page
    LANGUAGE sql STABLE
    AS $$
	SELECT *
	FROM user_page
	WHERE (
		page_id = get_user_page.page_id AND
		user_account_id = get_user_page.user_account_id
	);
$$;


ALTER FUNCTION article_api.get_user_page(page_id bigint, user_account_id bigint) OWNER TO postgres;

--
-- Name: list_comments(bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.list_comments(article_id bigint) RETURNS SETOF article_api.user_comment
    LANGUAGE sql
    AS $$
	SELECT * FROM article_api.user_comment WHERE article_id = list_comments.article_id;
$$;


ALTER FUNCTION article_api.list_comments(article_id bigint) OWNER TO postgres;

--
-- Name: list_hot_topics(integer, integer); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.list_hot_topics(page_number integer, page_size integer) RETURNS SETOF article_api.article_page_result
    LANGUAGE sql
    AS $$
	SELECT
		id,
		title,
		slug,
		source_id,
		source,
		date_published,
		date_modified,
		section,
		description,
		aotd_timestamp,
		score,
		url,
		authors,
		tags,
		word_count,
		readable_word_count,
		page_count,
		comment_count,
		latest_comment_date,
		read_count,
		latest_read_date,
		count(*) OVER() AS total_count
	FROM article_api.article
	WHERE
		(comment_count > 0 OR read_count > 1) AND
		(aotd_timestamp IS NULL OR aotd_timestamp != (SELECT max(aotd_timestamp) FROM article))
	ORDER BY score DESC
	OFFSET (page_number - 1) * page_size
	LIMIT page_size;
$$;


ALTER FUNCTION article_api.list_hot_topics(page_number integer, page_size integer) OWNER TO postgres;

--
-- Name: list_replies(bigint, integer, integer); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.list_replies(user_account_id bigint, page_number integer, page_size integer) RETURNS SETOF article_api.user_comment_page_result
    LANGUAGE sql
    AS $$
	SELECT
		reply.id,
		reply.date_created,
		reply.text,
		reply.article_id,
		reply.article_title,
		reply.article_slug,
		reply.user_account_id,
		reply.user_account,
		reply.parent_comment_id,
		reply.date_read,
		count(*) OVER() AS total_count
	FROM
		article_api.user_comment AS reply
		JOIN comment AS parent ON reply.parent_comment_id = parent.id
	WHERE parent.user_account_id = list_replies.user_account_id
	ORDER BY reply.date_created DESC
	OFFSET (page_number - 1) * page_size
	LIMIT page_size;
$$;


ALTER FUNCTION article_api.list_replies(user_account_id bigint, page_number integer, page_size integer) OWNER TO postgres;

--
-- Name: list_starred_articles(bigint, integer, integer); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.list_starred_articles(user_account_id bigint, page_number integer, page_size integer) RETURNS SETOF article_api.user_article_page_result
    LANGUAGE sql
    AS $$
	SELECT
		*,
		count(*) OVER() AS total_count
	FROM article_api.user_article
	WHERE
		user_account_id = list_starred_articles.user_account_id AND
		date_starred IS NOT NULL
	ORDER BY date_starred DESC
	OFFSET (page_number - 1) * page_size
	LIMIT page_size;
$$;


ALTER FUNCTION article_api.list_starred_articles(user_account_id bigint, page_number integer, page_size integer) OWNER TO postgres;

--
-- Name: list_user_article_history(bigint, integer, integer); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.list_user_article_history(user_account_id bigint, page_number integer, page_size integer) RETURNS SETOF article_api.user_article_page_result
    LANGUAGE sql
    AS $$
	SELECT
		*,
		count(*) OVER() AS total_count
	FROM article_api.user_article
	WHERE
		user_account_id = list_user_article_history.user_account_id AND
		(date_starred IS NOT NULL OR date_created IS NOT NULL)
	ORDER BY greatest(date_starred, date_created) DESC
	OFFSET (page_number - 1) * page_size
	LIMIT page_size;
$$;


ALTER FUNCTION article_api.list_user_article_history(user_account_id bigint, page_number integer, page_size integer) OWNER TO postgres;

--
-- Name: list_user_hot_topics(bigint, integer, integer); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.list_user_hot_topics(user_account_id bigint, page_number integer, page_size integer) RETURNS SETOF article_api.user_article_page_result
    LANGUAGE sql
    AS $$
	SELECT
		*,
		count(*) OVER() AS total_count
	FROM article_api.user_article
	WHERE
		user_account_id = list_user_hot_topics.user_account_id AND
		(comment_count > 0 OR read_count > 1) AND
		(aotd_timestamp IS NULL OR aotd_timestamp != (SELECT max(aotd_timestamp) FROM article))
	ORDER BY score DESC
	OFFSET (page_number - 1) * page_size
	LIMIT page_size;
$$;


ALTER FUNCTION article_api.list_user_hot_topics(user_account_id bigint, page_number integer, page_size integer) OWNER TO postgres;

--
-- Name: read_comment(bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.read_comment(comment_id bigint) RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE comment SET date_read = utc_now() WHERE id = comment_id AND date_read IS NULL;
$$;


ALTER FUNCTION article_api.read_comment(comment_id bigint) OWNER TO postgres;

--
-- Name: score_articles(); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.score_articles() RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE article
	SET score = coalesce(article_score.score, 0)
	FROM article_api.article_score
	WHERE article_score.article_id = article.id;
$$;


ALTER FUNCTION article_api.score_articles() OWNER TO postgres;

--
-- Name: set_aotd(); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.set_aotd() RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE article
	SET aotd_timestamp = utc_now()
	WHERE id = (
		SELECT id
		FROM article_api.article
		WHERE
			aotd_timestamp IS NULL AND
			word_count >= (184 * 5) AND
			(comment_count > 0 OR read_count > 1)
		ORDER BY score DESC
		LIMIT 1
	);
$$;


ALTER FUNCTION article_api.set_aotd() OWNER TO postgres;

--
-- Name: star_article(bigint, bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.star_article(user_account_id bigint, article_id bigint) RETURNS void
    LANGUAGE sql
    AS $$
	INSERT INTO star (user_account_id, article_id) VALUES (user_account_id, article_id);
$$;


ALTER FUNCTION article_api.star_article(user_account_id bigint, article_id bigint) OWNER TO postgres;

--
-- Name: unstar_article(bigint, bigint); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.unstar_article(user_account_id bigint, article_id bigint) RETURNS void
    LANGUAGE sql
    AS $$
	DELETE FROM star WHERE
		user_account_id = unstar_article.user_account_id AND
		article_id = unstar_article.article_id;
$$;


ALTER FUNCTION article_api.unstar_article(user_account_id bigint, article_id bigint) OWNER TO postgres;

--
-- Name: update_user_page(bigint, integer[]); Type: FUNCTION; Schema: article_api; Owner: postgres
--

CREATE FUNCTION article_api.update_user_page(user_page_id bigint, read_state integer[]) RETURNS core.user_page
    LANGUAGE plpgsql
    AS $$
<<locals>>
DECLARE
	words_read CONSTANT int NOT NULL := (SELECT sum(n) FROM unnest(read_state) AS n WHERE n > 0);
	page_id bigint;
	is_complete boolean;
	updated_user_page user_page;
BEGIN
	-- get the page_id and cache the completion state before updating the progress
	SELECT
		user_page.page_id,
		user_page.date_completed IS NOT NULL
	INTO
		locals.page_id,
		locals.is_complete
	FROM user_page
	WHERE user_page.id = update_user_page.user_page_id;
	-- update the progress
	UPDATE user_page
	SET
		read_state = update_user_page.read_state,
		words_read = locals.words_read,
		last_modified = utc_now()
	WHERE user_page.id = update_user_page.user_page_id
	RETURNING * INTO locals.updated_user_page;
	-- check if this update completed the page
	IF
		NOT is_complete AND
		(
			SELECT ((locals.words_read::double precision / page.readable_word_count) * 100) >= 90
			FROM page
			WHERE page.id = locals.page_id
		)
	THEN
		-- set date_completed
		UPDATE user_page
		SET date_completed = user_page.last_modified
		WHERE user_page.id = update_user_page.user_page_id
		RETURNING * INTO locals.updated_user_page;
		-- check for challenge win
		IF challenge_api.get_challenge_score(1, locals.updated_user_page.user_account_id) = (10, 10) THEN
			INSERT INTO challenge_award (challenge_id, user_account_id)
			VALUES (1, locals.updated_user_page.user_account_id);
		END IF;
	END IF;
	-- return
	RETURN locals.updated_user_page;
END;
$$;


ALTER FUNCTION article_api.update_user_page(user_page_id bigint, read_state integer[]) OWNER TO postgres;

--
-- Name: create_bulk_mailing(text, text, text, bigint, bigint[], boolean[]); Type: FUNCTION; Schema: bulk_mailing_api; Owner: postgres
--

CREATE FUNCTION bulk_mailing_api.create_bulk_mailing(subject text, body text, list text, user_account_id bigint, recipient_ids bigint[], recipient_results boolean[]) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
	bulk_mailing_id bigint;
BEGIN
	INSERT INTO bulk_mailing (subject, body, list, user_account_id)
		VALUES (subject, body, list, user_account_id)
		RETURNING id INTO bulk_mailing_id;
	FOR i IN 1..coalesce(array_length(recipient_ids, 1), 0) LOOP
		INSERT INTO bulk_mailing_recipient (bulk_mailing_id, user_account_id, is_successful)
			VALUES (bulk_mailing_id, recipient_ids[i], recipient_results[i]);
	END LOOP;
	RETURN bulk_mailing_id;
END;
$$;


ALTER FUNCTION bulk_mailing_api.create_bulk_mailing(subject text, body text, list text, user_account_id bigint, recipient_ids bigint[], recipient_results boolean[]) OWNER TO postgres;

--
-- Name: list_bulk_mailings(); Type: FUNCTION; Schema: bulk_mailing_api; Owner: postgres
--

CREATE FUNCTION bulk_mailing_api.list_bulk_mailings() RETURNS TABLE(id bigint, date_sent timestamp without time zone, subject text, body text, list text, user_account text, recipient_count bigint, error_count bigint)
    LANGUAGE sql
    AS $$
	SELECT
		bulk_mailing.id,
		bulk_mailing.date_sent,
		bulk_mailing.subject,
		bulk_mailing.body,
		bulk_mailing.list,
		user_account.name AS user_account,
		count(*) AS recipient_count,
		count(*) FILTER (WHERE NOT bulk_mailing_recipient.is_successful) AS error_count
		FROM bulk_mailing
		JOIN user_account ON bulk_mailing.user_account_id = user_account.id
		JOIN bulk_mailing_recipient ON bulk_mailing.id = bulk_mailing_recipient.bulk_mailing_id
		GROUP BY bulk_mailing.id, user_account.id;
$$;


ALTER FUNCTION bulk_mailing_api.list_bulk_mailings() OWNER TO postgres;

--
-- Name: email_confirmation; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.email_confirmation (
    id bigint NOT NULL,
    date_created timestamp without time zone DEFAULT core.utc_now() NOT NULL,
    user_account_id bigint NOT NULL,
    email_address text NOT NULL,
    date_confirmed timestamp without time zone
);


ALTER TABLE core.email_confirmation OWNER TO postgres;

--
-- Name: time_zone; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.time_zone (
    id bigint NOT NULL,
    name core.time_zone_name NOT NULL,
    display_name character varying(256) NOT NULL,
    territory character varying(3) NOT NULL,
    base_utc_offset interval hour to second NOT NULL
);


ALTER TABLE core.time_zone OWNER TO postgres;

--
-- Name: user_account; Type: VIEW; Schema: user_account_api; Owner: postgres
--

CREATE VIEW user_account_api.user_account AS
 SELECT user_account.id,
    user_account.name,
    user_account.email,
    user_account.password_hash,
    user_account.password_salt,
    user_account.receive_reply_email_notifications,
    user_account.receive_reply_desktop_notifications,
    user_account.last_new_reply_ack,
    user_account.last_new_reply_desktop_notification,
    user_account.date_created,
    user_account.role,
    user_account.receive_website_updates,
    user_account.receive_suggested_readings,
    (latest_email_confirmation.date_confirmed IS NOT NULL) AS is_email_confirmed,
    user_account.time_zone_id,
    time_zone.name AS time_zone_name,
    time_zone.display_name AS time_zone_display_name
   FROM ((core.user_account
     LEFT JOIN ( SELECT ec_left.user_account_id,
            ec_left.date_confirmed
           FROM (core.email_confirmation ec_left
             LEFT JOIN core.email_confirmation ec_right ON (((ec_right.user_account_id = ec_left.user_account_id) AND (ec_right.date_created > ec_left.date_created))))
          WHERE (ec_right.id IS NULL)) latest_email_confirmation ON ((latest_email_confirmation.user_account_id = user_account.id)))
     LEFT JOIN core.time_zone ON ((time_zone.id = user_account.time_zone_id)));


ALTER TABLE user_account_api.user_account OWNER TO postgres;

--
-- Name: list_confirmation_reminder_recipients(); Type: FUNCTION; Schema: bulk_mailing_api; Owner: postgres
--

CREATE FUNCTION bulk_mailing_api.list_confirmation_reminder_recipients() RETURNS SETOF user_account_api.user_account
    LANGUAGE sql STABLE
    AS $$
	SELECT
	DISTINCT ON (user_account.id)
		user_account.*
	FROM
		bulk_mailing
		JOIN bulk_mailing_recipient recipient ON recipient.bulk_mailing_id = bulk_mailing.id
		JOIN user_account_api.user_account ON user_account.id = recipient.user_account_id
	WHERE
		bulk_mailing.list = 'ConfirmationReminder';
$$;


ALTER FUNCTION bulk_mailing_api.list_confirmation_reminder_recipients() OWNER TO postgres;

--
-- Name: email_bounce; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.email_bounce (
    id bigint NOT NULL,
    date_received timestamp without time zone NOT NULL,
    address text NOT NULL,
    message text NOT NULL,
    bulk_mailing_id bigint
);


ALTER TABLE core.email_bounce OWNER TO postgres;

--
-- Name: list_email_bounces(); Type: FUNCTION; Schema: bulk_mailing_api; Owner: postgres
--

CREATE FUNCTION bulk_mailing_api.list_email_bounces() RETURNS SETOF core.email_bounce
    LANGUAGE sql
    AS $$
	SELECT
		id,
		date_received,
		address,
		message,
		bulk_mailing_id
	FROM email_bounce;
$$;


ALTER FUNCTION bulk_mailing_api.list_email_bounces() OWNER TO postgres;

--
-- Name: challenge_response; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.challenge_response (
    id bigint NOT NULL,
    challenge_id bigint NOT NULL,
    user_account_id bigint NOT NULL,
    date timestamp without time zone DEFAULT core.utc_now() NOT NULL,
    action core.challenge_response_action NOT NULL,
    time_zone_id bigint
);


ALTER TABLE core.challenge_response OWNER TO postgres;

--
-- Name: challenge_response; Type: VIEW; Schema: challenge_api; Owner: postgres
--

CREATE VIEW challenge_api.challenge_response AS
 SELECT challenge_response.id,
    challenge_response.challenge_id,
    challenge_response.user_account_id,
    challenge_response.date,
    challenge_response.action,
    challenge_response.time_zone_id,
    time_zone.name AS time_zone_name
   FROM (core.challenge_response
     LEFT JOIN core.time_zone ON ((time_zone.id = challenge_response.time_zone_id)));


ALTER TABLE challenge_api.challenge_response OWNER TO postgres;

--
-- Name: create_challenge_response(bigint, bigint, core.challenge_response_action, bigint); Type: FUNCTION; Schema: challenge_api; Owner: postgres
--

CREATE FUNCTION challenge_api.create_challenge_response(challenge_id bigint, user_account_id bigint, action core.challenge_response_action, time_zone_id bigint) RETURNS SETOF challenge_api.challenge_response
    LANGUAGE plpgsql
    AS $$
DECLARE
	challenge_response_id bigint;
BEGIN
	INSERT INTO challenge_response (
		challenge_id,
		user_account_id,
		action,
		time_zone_id
	)
	VALUES (
		create_challenge_response.challenge_id,
		create_challenge_response.user_account_id,
		create_challenge_response.action,
		create_challenge_response.time_zone_id
	)
	RETURNING id INTO challenge_response_id;
	RETURN QUERY
	SELECT *
	FROM challenge_api.challenge_response
	WHERE id = challenge_response_id;
END;
$$;


ALTER FUNCTION challenge_api.create_challenge_response(challenge_id bigint, user_account_id bigint, action core.challenge_response_action, time_zone_id bigint) OWNER TO postgres;

--
-- Name: challenge; Type: TABLE; Schema: challenge_api; Owner: postgres
--

CREATE TABLE challenge_api.challenge (
    id bigint,
    name character varying(256),
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    award_limit integer,
    award_count bigint
);

ALTER TABLE ONLY challenge_api.challenge REPLICA IDENTITY NOTHING;


ALTER TABLE challenge_api.challenge OWNER TO postgres;

--
-- Name: get_active_challenges(); Type: FUNCTION; Schema: challenge_api; Owner: postgres
--

CREATE FUNCTION challenge_api.get_active_challenges() RETURNS SETOF challenge_api.challenge
    LANGUAGE sql STABLE
    AS $$
	SELECT *
	FROM challenge_api.challenge
	WHERE tsrange(start_date, end_date) @> utc_now();
$$;


ALTER FUNCTION challenge_api.get_active_challenges() OWNER TO postgres;

--
-- Name: get_challenge_contenders(bigint); Type: FUNCTION; Schema: challenge_api; Owner: postgres
--

CREATE FUNCTION challenge_api.get_challenge_contenders(challenge_id bigint) RETURNS TABLE(name text, day integer, level integer)
    LANGUAGE sql STABLE
    AS $$
	SELECT
		c.name,
		c.day,
		c.level
	FROM challenge_api.challenge_contender c
	WHERE c.challenge_id = get_challenge_contenders.challenge_id
	ORDER BY c.level DESC, c.day, c.name;
$$;


ALTER FUNCTION challenge_api.get_challenge_contenders(challenge_id bigint) OWNER TO postgres;

--
-- Name: get_challenge_response_action_totals(bigint); Type: FUNCTION; Schema: challenge_api; Owner: postgres
--

CREATE FUNCTION challenge_api.get_challenge_response_action_totals(challenge_id bigint) RETURNS TABLE(action core.challenge_response_action, count bigint)
    LANGUAGE sql STABLE
    AS $$
	SELECT
		action,
		count(*)
	FROM challenge_response
	WHERE challenge_id = get_challenge_response_action_totals.challenge_id
	GROUP BY action
	ORDER BY action;
$$;


ALTER FUNCTION challenge_api.get_challenge_response_action_totals(challenge_id bigint) OWNER TO postgres;

--
-- Name: get_challenge_score(bigint, bigint); Type: FUNCTION; Schema: challenge_api; Owner: postgres
--

CREATE FUNCTION challenge_api.get_challenge_score(challenge_id bigint, user_account_id bigint) RETURNS TABLE(day integer, level integer)
    LANGUAGE plpgsql STABLE
    AS $$
<<locals>>
DECLARE
	enrollment_date timestamp;
	time_zone_name text;
BEGIN
	-- check if the challenge is active
	IF get_challenge_score.challenge_id IN (
		SELECT c.id
		FROM challenge_api.get_active_challenges() c
	)
	THEN
		-- check if the user won the challenge
		IF get_challenge_score.user_account_id IN (
			SELECT ca.user_account_id
			FROM challenge_award ca
			WHERE ca.challenge_id = get_challenge_score.challenge_id
		) THEN
			RETURN QUERY SELECT 0, 10;
			RETURN;
		END IF;
		-- check for an enrollment date
		SELECT
			CASE WHEN cr.action = 'enroll'
				THEN cr.date
				ELSE NULL
			END,
			cr.time_zone_name
			INTO
				locals.enrollment_date,
				locals.time_zone_name
		FROM challenge_api.challenge_response cr
		WHERE
			cr.challenge_id = get_challenge_score.challenge_id AND
			cr.user_account_id = get_challenge_score.user_account_id
		ORDER BY cr.date DESC
		LIMIT 1;
		IF locals.enrollment_date IS NOT NULL THEN
			RETURN QUERY
			WITH qualifying_read AS (
				SELECT
					read.date_completed
				FROM
					article_api.user_article_read read
					JOIN article_api.article_pages pages ON read.article_id = pages.article_id
				WHERE
					read.user_account_id = get_challenge_score.user_account_id AND
					read.date_completed >= locals.enrollment_date AND
					pages.word_count >= (184 * 5)
			),
			daily_read_count AS (
				SELECT
					series.local_day,
					count(read.*) AS read_count
				FROM
					generate_local_to_utc_date_series(
						cast(local_now(locals.time_zone_name) - '9 days'::interval AS date),
						cast(local_now(locals.time_zone_name) AS date),
						1,
						locals.time_zone_name
					) AS series
					LEFT JOIN qualifying_read read ON series.utc_range @> read.date_completed
				GROUP BY series.local_day
			),
			qualified_daily_read_count AS (
				SELECT
					drc.local_day,
					drc.read_count,
					CASE WHEN
						drc.local_day = first_value(drc.local_day) OVER local_day_desc AND
						lead(drc.read_count) OVER local_day_desc > 0
						THEN TRUE
						ELSE drc.read_count > 0
					END AS is_qualifying_day
				FROM daily_read_count drc
				WINDOW local_day_desc AS (ORDER BY drc.local_day DESC)
			),
			steaked_daily_read_count AS (
				SELECT
					qdrc.local_day,
					qdrc.read_count,
					sum(
						CASE WHEN qdrc.is_qualifying_day
							THEN 0
							ELSE 1
						END
					) OVER (ORDER BY qdrc.local_day DESC) = 0 AS is_streak_day
				FROM qualified_daily_read_count qdrc
			)
			SELECT
				cast(count(*) AS int),
				cast(count(*) FILTER (WHERE sdrc.read_count > 0) AS int)
			FROM steaked_daily_read_count sdrc
			WHERE sdrc.is_streak_day;
			RETURN;
		END IF;
	END IF;
	RETURN QUERY SELECT 0, 0;
END;
$$;


ALTER FUNCTION challenge_api.get_challenge_score(challenge_id bigint, user_account_id bigint) OWNER TO postgres;

--
-- Name: get_challenge_winners(bigint); Type: FUNCTION; Schema: challenge_api; Owner: postgres
--

CREATE FUNCTION challenge_api.get_challenge_winners(challenge_id bigint) RETURNS TABLE(name text, email text, date_awarded timestamp without time zone)
    LANGUAGE sql STABLE
    AS $$
	SELECT
		ua.name,
		ua.email,
		ca.date_awarded
	FROM
		challenge_award ca
		JOIN user_account ua ON ca.user_account_id = ua.id
	WHERE ca.challenge_id = get_challenge_winners.challenge_id
	ORDER BY ca.date_awarded;
$$;


ALTER FUNCTION challenge_api.get_challenge_winners(challenge_id bigint) OWNER TO postgres;

--
-- Name: get_latest_challenge_response(bigint, bigint); Type: FUNCTION; Schema: challenge_api; Owner: postgres
--

CREATE FUNCTION challenge_api.get_latest_challenge_response(challenge_id bigint, user_account_id bigint) RETURNS SETOF challenge_api.challenge_response
    LANGUAGE sql STABLE
    AS $$
	SELECT *
	FROM challenge_api.latest_challenge_response lcr
	WHERE
		lcr.challenge_id = get_latest_challenge_response.challenge_id AND
		lcr.user_account_id = get_latest_challenge_response.user_account_id;
$$;


ALTER FUNCTION challenge_api.get_latest_challenge_response(challenge_id bigint, user_account_id bigint) OWNER TO postgres;

--
-- Name: generate_local_to_utc_date_series(date, date, integer, text); Type: FUNCTION; Schema: core; Owner: postgres
--

CREATE FUNCTION core.generate_local_to_utc_date_series(start date, stop date, day_step_count integer, time_zone_name text) RETURNS TABLE(local_day date, utc_range tsrange)
    LANGUAGE sql IMMUTABLE
    AS $$
	WITH day_pair AS (
		SELECT
			cast(local_day AS date) AS local_day,
			make_timestamptz(
				extract(year FROM local_day)::int,
				extract(month FROM local_day)::int,
				extract(day FROM local_day)::int,
				extract(hour FROM local_day)::int,
				extract(minute FROM local_day)::int,
				extract(second FROM local_day)::int,
				generate_local_to_utc_date_series.time_zone_name
			) AT TIME ZONE 'UTC' AS utc_day
		FROM
			generate_series(
				start,
				stop,
				make_interval(
					days => generate_local_to_utc_date_series.day_step_count
				)
			) AS local_day
	)
	SELECT
		local_day,
		tsrange(
			utc_day,
			utc_day + '1 day'::interval
		)
	FROM day_pair;
$$;


ALTER FUNCTION core.generate_local_to_utc_date_series(start date, stop date, day_step_count integer, time_zone_name text) OWNER TO postgres;

--
-- Name: get_time_zones(); Type: FUNCTION; Schema: core; Owner: postgres
--

CREATE FUNCTION core.get_time_zones() RETURNS SETOF core.time_zone
    LANGUAGE sql STABLE
    AS $$
	SELECT *
	FROM time_zone;
$$;


ALTER FUNCTION core.get_time_zones() OWNER TO postgres;

--
-- Name: local_now(text); Type: FUNCTION; Schema: core; Owner: postgres
--

CREATE FUNCTION core.local_now(time_zone_name text) RETURNS timestamp without time zone
    LANGUAGE sql STABLE
    AS $$
	SELECT now() AT TIME ZONE time_zone_name;
$$;


ALTER FUNCTION core.local_now(time_zone_name text) OWNER TO postgres;

--
-- Name: ack_new_reply(bigint); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.ack_new_reply(user_account_id bigint) RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE user_account SET last_new_reply_ack = utc_now() WHERE id = user_account_id;
$$;


ALTER FUNCTION user_account_api.ack_new_reply(user_account_id bigint) OWNER TO postgres;

--
-- Name: change_email_address(bigint, text); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.change_email_address(user_account_id bigint, email text) RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE user_account
		SET email = change_email_address.email
		WHERE id = user_account_id;
$$;


ALTER FUNCTION user_account_api.change_email_address(user_account_id bigint, email text) OWNER TO postgres;

--
-- Name: change_password(bigint, bytea, bytea); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.change_password(user_account_id bigint, password_hash bytea, password_salt bytea) RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE user_account
		SET
			password_hash = change_password.password_hash,
			password_salt = change_password.password_salt
		WHERE id = user_account_id;
$$;


ALTER FUNCTION user_account_api.change_password(user_account_id bigint, password_hash bytea, password_salt bytea) OWNER TO postgres;

--
-- Name: complete_password_reset_request(bigint); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.complete_password_reset_request(password_reset_request_id bigint) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
	rows_updated int;
BEGIN
	UPDATE password_reset_request
		SET date_completed = utc_now()
		WHERE id = password_reset_request_id AND date_completed IS NULL;
	GET DIAGNOSTICS rows_updated = ROW_COUNT;
	RETURN rows_updated = 1;
END;
$$;


ALTER FUNCTION user_account_api.complete_password_reset_request(password_reset_request_id bigint) OWNER TO postgres;

--
-- Name: confirm_email_address(bigint); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.confirm_email_address(email_confirmation_id bigint) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
	rows_updated int;
BEGIN
	UPDATE email_confirmation SET date_confirmed = utc_now() WHERE id = email_confirmation_id AND date_confirmed IS NULL;
	GET DIAGNOSTICS rows_updated = ROW_COUNT;
	RETURN rows_updated = 1;
END;
$$;


ALTER FUNCTION user_account_api.confirm_email_address(email_confirmation_id bigint) OWNER TO postgres;

--
-- Name: create_email_confirmation(bigint); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.create_email_confirmation(user_account_id bigint) RETURNS SETOF core.email_confirmation
    LANGUAGE sql
    AS $$
	INSERT INTO email_confirmation (user_account_id, email_address)
		VALUES (user_account_id, (SELECT email FROM user_account WHERE id = user_account_id))
		RETURNING *;
$$;


ALTER FUNCTION user_account_api.create_email_confirmation(user_account_id bigint) OWNER TO postgres;

--
-- Name: password_reset_request; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.password_reset_request (
    id bigint NOT NULL,
    date_created timestamp without time zone DEFAULT core.utc_now() NOT NULL,
    user_account_id bigint NOT NULL,
    email_address text NOT NULL,
    date_completed timestamp without time zone
);


ALTER TABLE core.password_reset_request OWNER TO postgres;

--
-- Name: create_password_reset_request(bigint); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.create_password_reset_request(user_account_id bigint) RETURNS SETOF core.password_reset_request
    LANGUAGE sql
    AS $$
	INSERT INTO password_reset_request (user_account_id, email_address)
		VALUES (user_account_id, (SELECT email FROM user_account WHERE id = user_account_id))
		RETURNING *;
$$;


ALTER FUNCTION user_account_api.create_password_reset_request(user_account_id bigint) OWNER TO postgres;

--
-- Name: create_user_account(text, text, bytea, bytea); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.create_user_account(name text, email text, password_hash bytea, password_salt bytea) RETURNS SETOF user_account_api.user_account
    LANGUAGE plpgsql
    AS $$
DECLARE
	user_account_id bigint;
BEGIN
	INSERT INTO user_account (name, email, password_hash, password_salt)
		VALUES (trim(name), trim(email), password_hash, password_salt)
		RETURNING id INTO user_account_id;
	RETURN QUERY
	SELECT *
	FROM user_account_api.user_account
	WHERE id = user_account_id;
END;
$$;


ALTER FUNCTION user_account_api.create_user_account(name text, email text, password_hash bytea, password_salt bytea) OWNER TO postgres;

--
-- Name: find_user_account(text); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.find_user_account(email text) RETURNS SETOF user_account_api.user_account
    LANGUAGE sql STABLE
    AS $$
	SELECT *
	FROM user_account_api.user_account
	WHERE lower(email) = lower(find_user_account.email);
$$;


ALTER FUNCTION user_account_api.find_user_account(email text) OWNER TO postgres;

--
-- Name: get_email_confirmation(bigint); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.get_email_confirmation(email_confirmation_id bigint) RETURNS SETOF core.email_confirmation
    LANGUAGE sql
    AS $$
	SELECT * FROM email_confirmation WHERE id = email_confirmation_id;
$$;


ALTER FUNCTION user_account_api.get_email_confirmation(email_confirmation_id bigint) OWNER TO postgres;

--
-- Name: get_latest_password_reset_request(bigint); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.get_latest_password_reset_request(user_account_id bigint) RETURNS SETOF core.password_reset_request
    LANGUAGE sql
    AS $$
	SELECT * FROM password_reset_request
		WHERE user_account_id = get_latest_password_reset_request.user_account_id
		ORDER BY date_created DESC
		LIMIT 1;
$$;


ALTER FUNCTION user_account_api.get_latest_password_reset_request(user_account_id bigint) OWNER TO postgres;

--
-- Name: get_latest_unconfirmed_email_confirmation(bigint); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.get_latest_unconfirmed_email_confirmation(user_account_id bigint) RETURNS SETOF core.email_confirmation
    LANGUAGE sql
    AS $$
	SELECT * FROM email_confirmation
		WHERE
			user_account_id = get_latest_unconfirmed_email_confirmation.user_account_id AND
			date_confirmed IS NULL
		ORDER BY date_created DESC
		LIMIT 1;
$$;


ALTER FUNCTION user_account_api.get_latest_unconfirmed_email_confirmation(user_account_id bigint) OWNER TO postgres;

--
-- Name: get_latest_unread_reply(bigint); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.get_latest_unread_reply(user_account_id bigint) RETURNS SETOF article_api.user_comment
    LANGUAGE sql
    AS $$
	SELECT reply.* FROM article_api.user_comment reply
		JOIN comment parent ON reply.parent_comment_id = parent.id AND reply.user_account_id != parent.user_account_id
		JOIN user_account ON parent.user_account_id = user_account.id
		WHERE user_account.id = get_latest_unread_reply.user_account_id AND reply.date_read IS NULL
		ORDER BY reply.date_created DESC
		LIMIT 1;
$$;


ALTER FUNCTION user_account_api.get_latest_unread_reply(user_account_id bigint) OWNER TO postgres;

--
-- Name: get_password_reset_request(bigint); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.get_password_reset_request(password_reset_request_id bigint) RETURNS SETOF core.password_reset_request
    LANGUAGE sql
    AS $$
	SELECT * FROM password_reset_request WHERE id = password_reset_request_id;
$$;


ALTER FUNCTION user_account_api.get_password_reset_request(password_reset_request_id bigint) OWNER TO postgres;

--
-- Name: get_user_account(bigint); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.get_user_account(user_account_id bigint) RETURNS SETOF user_account_api.user_account
    LANGUAGE sql STABLE
    AS $$
	SELECT *
	FROM user_account_api.user_account
	WHERE id = user_account_id;
$$;


ALTER FUNCTION user_account_api.get_user_account(user_account_id bigint) OWNER TO postgres;

--
-- Name: get_user_account_using_old_id(uuid); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.get_user_account_using_old_id(user_account_id uuid) RETURNS SETOF user_account_api.user_account
    LANGUAGE sql STABLE
    AS $$
SELECT user_account.*
	FROM user_account_api.user_account
	JOIN id_migration.user_account AS lookup ON (
		lookup.new_id = user_account.id AND
		lookup.old_id = get_user_account_using_old_id.user_account_id
	);
$$;


ALTER FUNCTION user_account_api.get_user_account_using_old_id(user_account_id uuid) OWNER TO postgres;

--
-- Name: is_email_address_confirmed(bigint, text); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.is_email_address_confirmed(user_account_id bigint, email text) RETURNS boolean
    LANGUAGE sql
    AS $$
	SELECT EXISTS(
		SELECT 1 FROM email_confirmation WHERE
			user_account_id = is_email_address_confirmed.user_account_id AND
			lower(email_address) = lower(email) AND
			date_confirmed IS NOT NULL
	);
$$;


ALTER FUNCTION user_account_api.is_email_address_confirmed(user_account_id bigint, email text) OWNER TO postgres;

--
-- Name: list_email_confirmations(bigint); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.list_email_confirmations(user_account_id bigint) RETURNS SETOF core.email_confirmation
    LANGUAGE sql
    AS $$
	SELECT
		id,
		date_created,
		user_account_id,
		email_address,
		date_confirmed
	FROM
		email_confirmation
	WHERE
		user_account_id = list_email_confirmations.user_account_id
	ORDER BY date_created DESC;
$$;


ALTER FUNCTION user_account_api.list_email_confirmations(user_account_id bigint) OWNER TO postgres;

--
-- Name: list_user_accounts(); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.list_user_accounts() RETURNS SETOF user_account_api.user_account
    LANGUAGE sql STABLE
    AS $$
	SELECT *
	FROM user_account_api.user_account;
$$;


ALTER FUNCTION user_account_api.list_user_accounts() OWNER TO postgres;

--
-- Name: record_new_reply_desktop_notification(bigint); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.record_new_reply_desktop_notification(user_account_id bigint) RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE user_account SET last_new_reply_desktop_notification = utc_now() WHERE id = user_account_id;
$$;


ALTER FUNCTION user_account_api.record_new_reply_desktop_notification(user_account_id bigint) OWNER TO postgres;

--
-- Name: update_contact_preferences(bigint, boolean, boolean); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.update_contact_preferences(user_account_id bigint, receive_website_updates boolean, receive_suggested_readings boolean) RETURNS SETOF user_account_api.user_account
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE user_account
	SET
		receive_website_updates = update_contact_preferences.receive_website_updates,
		receive_suggested_readings = update_contact_preferences.receive_suggested_readings
	WHERE id = user_account_id;
	RETURN QUERY
	SELECT *
	FROM user_account_api.user_account
	WHERE id = user_account_id;
END;
$$;


ALTER FUNCTION user_account_api.update_contact_preferences(user_account_id bigint, receive_website_updates boolean, receive_suggested_readings boolean) OWNER TO postgres;

--
-- Name: update_notification_preferences(bigint, boolean, boolean); Type: FUNCTION; Schema: user_account_api; Owner: postgres
--

CREATE FUNCTION user_account_api.update_notification_preferences(user_account_id bigint, receive_reply_email_notifications boolean, receive_reply_desktop_notifications boolean) RETURNS SETOF user_account_api.user_account
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE user_account
	SET
		receive_reply_email_notifications = update_notification_preferences.receive_reply_email_notifications,
		receive_reply_desktop_notifications = update_notification_preferences.receive_reply_desktop_notifications
	WHERE id = user_account_id;
	RETURN QUERY
	SELECT *
	FROM user_account_api.user_account
	WHERE id = user_account_id;
END;
$$;


ALTER FUNCTION user_account_api.update_notification_preferences(user_account_id bigint, receive_reply_email_notifications boolean, receive_reply_desktop_notifications boolean) OWNER TO postgres;

--
-- Name: user_article_read; Type: VIEW; Schema: article_api; Owner: postgres
--

CREATE VIEW article_api.user_article_read AS
 SELECT user_article_progress.words_read,
    user_article_progress.date_created,
    user_article_progress.last_modified,
    user_article_progress.percent_complete,
    user_article_progress.date_completed,
    user_article_progress.user_account_id,
    user_article_progress.article_id
   FROM article_api.user_article_progress
  WHERE user_article_progress.is_read;


ALTER TABLE article_api.user_article_read OWNER TO postgres;

--
-- Name: article_score; Type: VIEW; Schema: article_api; Owner: postgres
--

CREATE VIEW article_api.article_score AS
 SELECT article_pages.article_id,
    (COALESCE(comments.score, (0)::bigint) + (((COALESCE(reads.score, (0)::bigint))::double precision * GREATEST((1)::double precision, (((article_pages.word_count)::double precision / (184)::double precision) / (5)::double precision))))::integer) AS score
   FROM ((article_api.article_pages
     LEFT JOIN ( SELECT sum(
                CASE
                    WHEN (comment.age < '36:00:00'::interval) THEN 200
                    WHEN (comment.age < '72:00:00'::interval) THEN 150
                    WHEN (comment.age < '7 days'::interval) THEN 100
                    WHEN (comment.age < '14 days'::interval) THEN 50
                    WHEN (comment.age < '1 mon'::interval) THEN 5
                    ELSE 1
                END) AS score,
            comment.article_id
           FROM ( SELECT comment_1.article_id,
                    (core.utc_now() - comment_1.date_created) AS age
                   FROM core.comment comment_1) comment
          GROUP BY comment.article_id) comments ON ((comments.article_id = article_pages.article_id)))
     LEFT JOIN ( SELECT sum(
                CASE
                    WHEN (read.age < '36:00:00'::interval) THEN 175
                    WHEN (read.age < '72:00:00'::interval) THEN 125
                    WHEN (read.age < '7 days'::interval) THEN 75
                    WHEN (read.age < '14 days'::interval) THEN 25
                    WHEN (read.age < '1 mon'::interval) THEN 5
                    ELSE 1
                END) AS score,
            read.article_id
           FROM ( SELECT user_article_read.article_id,
                    (core.utc_now() - user_article_read.last_modified) AS age
                   FROM article_api.user_article_read) read
          GROUP BY read.article_id) reads ON ((reads.article_id = article_pages.article_id)));


ALTER TABLE article_api.article_score OWNER TO postgres;

--
-- Name: latest_challenge_response; Type: VIEW; Schema: challenge_api; Owner: postgres
--

CREATE VIEW challenge_api.latest_challenge_response AS
 SELECT cr_left.id,
    cr_left.challenge_id,
    cr_left.user_account_id,
    cr_left.date,
    cr_left.action,
    cr_left.time_zone_id,
    cr_left.time_zone_name
   FROM (challenge_api.challenge_response cr_left
     LEFT JOIN core.challenge_response cr_right ON (((cr_right.challenge_id = cr_left.challenge_id) AND (cr_right.user_account_id = cr_left.user_account_id) AND (cr_right.date > cr_left.date))))
  WHERE (cr_right.id IS NULL);


ALTER TABLE challenge_api.latest_challenge_response OWNER TO postgres;

--
-- Name: challenge; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.challenge (
    id bigint NOT NULL,
    name character varying(256) NOT NULL,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone,
    award_limit integer NOT NULL
);


ALTER TABLE core.challenge OWNER TO postgres;

--
-- Name: challenge_award; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.challenge_award (
    id bigint NOT NULL,
    challenge_id bigint NOT NULL,
    user_account_id bigint NOT NULL,
    date_awarded timestamp without time zone DEFAULT core.utc_now() NOT NULL,
    date_fulfilled timestamp without time zone,
    reference character varying(1024)
);


ALTER TABLE core.challenge_award OWNER TO postgres;

--
-- Name: challenge_contender; Type: MATERIALIZED VIEW; Schema: challenge_api; Owner: postgres
--

CREATE MATERIALIZED VIEW challenge_api.challenge_contender AS
 WITH contender AS (
         SELECT c_1.id AS challenge_id,
            lcr.user_account_id
           FROM ((core.challenge c_1
             JOIN challenge_api.latest_challenge_response lcr ON ((c_1.id = lcr.challenge_id)))
             LEFT JOIN core.challenge_award ca ON (((c_1.id = ca.challenge_id) AND (lcr.user_account_id = ca.user_account_id))))
          WHERE ((tsrange(c_1.start_date, c_1.end_date) @> core.utc_now()) AND (lcr.action = 'enroll'::core.challenge_response_action) AND (ca.id IS NULL))
        )
 SELECT c.challenge_id,
    ua.name,
    score.day,
    score.level
   FROM ((contender c
     JOIN core.user_account ua ON ((c.user_account_id = ua.id)))
     JOIN LATERAL challenge_api.get_challenge_score(c.challenge_id, ua.id) score(day, level) ON (true))
  WHERE (score.day > 0)
  ORDER BY score.level DESC, score.day, ua.name
  WITH NO DATA;


ALTER TABLE challenge_api.challenge_contender OWNER TO postgres;

--
-- Name: article_author; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.article_author (
    article_id bigint NOT NULL,
    author_id bigint NOT NULL
);


ALTER TABLE core.article_author OWNER TO postgres;

--
-- Name: article_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.article_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.article_id_seq OWNER TO postgres;

--
-- Name: article_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.article_id_seq OWNED BY core.article.id;


--
-- Name: article_tag; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.article_tag (
    article_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


ALTER TABLE core.article_tag OWNER TO postgres;

--
-- Name: author; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.author (
    id bigint NOT NULL,
    name text NOT NULL,
    url text
);


ALTER TABLE core.author OWNER TO postgres;

--
-- Name: author_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.author_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.author_id_seq OWNER TO postgres;

--
-- Name: author_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.author_id_seq OWNED BY core.author.id;


--
-- Name: bulk_mailing; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.bulk_mailing (
    id bigint NOT NULL,
    date_sent timestamp without time zone DEFAULT core.utc_now() NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    list text NOT NULL,
    user_account_id bigint NOT NULL
);


ALTER TABLE core.bulk_mailing OWNER TO postgres;

--
-- Name: bulk_mailing_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.bulk_mailing_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.bulk_mailing_id_seq OWNER TO postgres;

--
-- Name: bulk_mailing_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.bulk_mailing_id_seq OWNED BY core.bulk_mailing.id;


--
-- Name: bulk_mailing_recipient; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.bulk_mailing_recipient (
    bulk_mailing_id bigint NOT NULL,
    user_account_id bigint NOT NULL,
    is_successful boolean NOT NULL
);


ALTER TABLE core.bulk_mailing_recipient OWNER TO postgres;

--
-- Name: challenge_award_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.challenge_award_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.challenge_award_id_seq OWNER TO postgres;

--
-- Name: challenge_award_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.challenge_award_id_seq OWNED BY core.challenge_award.id;


--
-- Name: challenge_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.challenge_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.challenge_id_seq OWNER TO postgres;

--
-- Name: challenge_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.challenge_id_seq OWNED BY core.challenge.id;


--
-- Name: challenge_response_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.challenge_response_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.challenge_response_id_seq OWNER TO postgres;

--
-- Name: challenge_response_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.challenge_response_id_seq OWNED BY core.challenge_response.id;


--
-- Name: comment_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.comment_id_seq OWNER TO postgres;

--
-- Name: comment_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.comment_id_seq OWNED BY core.comment.id;


--
-- Name: email_bounce_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.email_bounce_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.email_bounce_id_seq OWNER TO postgres;

--
-- Name: email_bounce_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.email_bounce_id_seq OWNED BY core.email_bounce.id;


--
-- Name: email_confirmation_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.email_confirmation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.email_confirmation_id_seq OWNER TO postgres;

--
-- Name: email_confirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.email_confirmation_id_seq OWNED BY core.email_confirmation.id;


--
-- Name: email_share; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.email_share (
    id bigint NOT NULL,
    date_sent timestamp without time zone NOT NULL,
    article_id bigint NOT NULL,
    user_account_id bigint NOT NULL,
    message character varying(10000)
);


ALTER TABLE core.email_share OWNER TO postgres;

--
-- Name: email_share_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.email_share_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.email_share_id_seq OWNER TO postgres;

--
-- Name: email_share_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.email_share_id_seq OWNED BY core.email_share.id;


--
-- Name: email_share_recipient; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.email_share_recipient (
    id bigint NOT NULL,
    email_share_id bigint NOT NULL,
    email_address character varying(256) NOT NULL,
    user_account_id bigint,
    is_successful boolean NOT NULL
);


ALTER TABLE core.email_share_recipient OWNER TO postgres;

--
-- Name: email_share_recipient_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.email_share_recipient_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.email_share_recipient_id_seq OWNER TO postgres;

--
-- Name: email_share_recipient_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.email_share_recipient_id_seq OWNED BY core.email_share_recipient.id;


--
-- Name: page_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.page_id_seq OWNER TO postgres;

--
-- Name: page_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.page_id_seq OWNED BY core.page.id;


--
-- Name: password_reset_request_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.password_reset_request_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.password_reset_request_id_seq OWNER TO postgres;

--
-- Name: password_reset_request_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.password_reset_request_id_seq OWNED BY core.password_reset_request.id;


--
-- Name: source_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.source_id_seq OWNER TO postgres;

--
-- Name: source_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.source_id_seq OWNED BY core.source.id;


--
-- Name: source_rule_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.source_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.source_rule_id_seq OWNER TO postgres;

--
-- Name: source_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.source_rule_id_seq OWNED BY core.source_rule.id;


--
-- Name: tag; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.tag (
    id bigint NOT NULL,
    name text NOT NULL
);


ALTER TABLE core.tag OWNER TO postgres;

--
-- Name: tag_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.tag_id_seq OWNER TO postgres;

--
-- Name: tag_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.tag_id_seq OWNED BY core.tag.id;


--
-- Name: user_account_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.user_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.user_account_id_seq OWNER TO postgres;

--
-- Name: user_account_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.user_account_id_seq OWNED BY core.user_account.id;


--
-- Name: user_page_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.user_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.user_page_id_seq OWNER TO postgres;

--
-- Name: user_page_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.user_page_id_seq OWNED BY core.user_page.id;


--
-- Name: user_account; Type: TABLE; Schema: id_migration; Owner: postgres
--

CREATE TABLE id_migration.user_account (
    old_id uuid,
    new_id bigint
);


ALTER TABLE id_migration.user_account OWNER TO postgres;

--
-- Name: article id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.article ALTER COLUMN id SET DEFAULT nextval('core.article_id_seq'::regclass);


--
-- Name: author id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.author ALTER COLUMN id SET DEFAULT nextval('core.author_id_seq'::regclass);


--
-- Name: bulk_mailing id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.bulk_mailing ALTER COLUMN id SET DEFAULT nextval('core.bulk_mailing_id_seq'::regclass);


--
-- Name: challenge id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.challenge ALTER COLUMN id SET DEFAULT nextval('core.challenge_id_seq'::regclass);


--
-- Name: challenge_award id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.challenge_award ALTER COLUMN id SET DEFAULT nextval('core.challenge_award_id_seq'::regclass);


--
-- Name: challenge_response id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.challenge_response ALTER COLUMN id SET DEFAULT nextval('core.challenge_response_id_seq'::regclass);


--
-- Name: comment id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.comment ALTER COLUMN id SET DEFAULT nextval('core.comment_id_seq'::regclass);


--
-- Name: email_bounce id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_bounce ALTER COLUMN id SET DEFAULT nextval('core.email_bounce_id_seq'::regclass);


--
-- Name: email_confirmation id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_confirmation ALTER COLUMN id SET DEFAULT nextval('core.email_confirmation_id_seq'::regclass);


--
-- Name: email_share id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_share ALTER COLUMN id SET DEFAULT nextval('core.email_share_id_seq'::regclass);


--
-- Name: email_share_recipient id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_share_recipient ALTER COLUMN id SET DEFAULT nextval('core.email_share_recipient_id_seq'::regclass);


--
-- Name: page id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.page ALTER COLUMN id SET DEFAULT nextval('core.page_id_seq'::regclass);


--
-- Name: password_reset_request id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.password_reset_request ALTER COLUMN id SET DEFAULT nextval('core.password_reset_request_id_seq'::regclass);


--
-- Name: source id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.source ALTER COLUMN id SET DEFAULT nextval('core.source_id_seq'::regclass);


--
-- Name: source_rule id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.source_rule ALTER COLUMN id SET DEFAULT nextval('core.source_rule_id_seq'::regclass);


--
-- Name: tag id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.tag ALTER COLUMN id SET DEFAULT nextval('core.tag_id_seq'::regclass);


--
-- Name: user_account id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.user_account ALTER COLUMN id SET DEFAULT nextval('core.user_account_id_seq'::regclass);


--
-- Name: user_page id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.user_page ALTER COLUMN id SET DEFAULT nextval('core.user_page_id_seq'::regclass);


--
-- Data for Name: article; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.article (id, title, slug, source_id, date_published, date_modified, section, description, aotd_timestamp, score) FROM stdin;
\.
COPY core.article (id, title, slug, source_id, date_published, date_modified, section, description, aotd_timestamp, score) FROM '$$PATH$$/2546.dat';

--
-- Data for Name: article_author; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.article_author (article_id, author_id) FROM stdin;
\.
COPY core.article_author (article_id, author_id) FROM '$$PATH$$/2562.dat';

--
-- Name: article_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.article_id_seq', 129708, true);


--
-- Data for Name: article_tag; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.article_tag (article_id, tag_id) FROM stdin;
\.
COPY core.article_tag (article_id, tag_id) FROM '$$PATH$$/2564.dat';

--
-- Data for Name: author; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.author (id, name, url) FROM stdin;
\.
COPY core.author (id, name, url) FROM '$$PATH$$/2565.dat';

--
-- Name: author_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.author_id_seq', 58187, true);


--
-- Data for Name: bulk_mailing; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.bulk_mailing (id, date_sent, subject, body, list, user_account_id) FROM stdin;
\.
COPY core.bulk_mailing (id, date_sent, subject, body, list, user_account_id) FROM '$$PATH$$/2567.dat';

--
-- Name: bulk_mailing_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.bulk_mailing_id_seq', 11, true);


--
-- Data for Name: bulk_mailing_recipient; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.bulk_mailing_recipient (bulk_mailing_id, user_account_id, is_successful) FROM stdin;
\.
COPY core.bulk_mailing_recipient (bulk_mailing_id, user_account_id, is_successful) FROM '$$PATH$$/2569.dat';

--
-- Data for Name: challenge; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.challenge (id, name, start_date, end_date, award_limit) FROM stdin;
\.
COPY core.challenge (id, name, start_date, end_date, award_limit) FROM '$$PATH$$/2559.dat';

--
-- Data for Name: challenge_award; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.challenge_award (id, challenge_id, user_account_id, date_awarded, date_fulfilled, reference) FROM stdin;
\.
COPY core.challenge_award (id, challenge_id, user_account_id, date_awarded, date_fulfilled, reference) FROM '$$PATH$$/2560.dat';

--
-- Name: challenge_award_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.challenge_award_id_seq', 31, true);


--
-- Name: challenge_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.challenge_id_seq', 1, false);


--
-- Data for Name: challenge_response; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.challenge_response (id, challenge_id, user_account_id, date, action, time_zone_id) FROM stdin;
\.
COPY core.challenge_response (id, challenge_id, user_account_id, date, action, time_zone_id) FROM '$$PATH$$/2557.dat';

--
-- Name: challenge_response_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.challenge_response_id_seq', 138, true);


--
-- Data for Name: comment; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.comment (id, date_created, text, article_id, user_account_id, parent_comment_id, date_read) FROM stdin;
\.
COPY core.comment (id, date_created, text, article_id, user_account_id, parent_comment_id, date_read) FROM '$$PATH$$/2547.dat';

--
-- Name: comment_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.comment_id_seq', 1370, true);


--
-- Data for Name: email_bounce; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.email_bounce (id, date_received, address, message, bulk_mailing_id) FROM stdin;
\.
COPY core.email_bounce (id, date_received, address, message, bulk_mailing_id) FROM '$$PATH$$/2556.dat';

--
-- Name: email_bounce_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.email_bounce_id_seq', 7, true);


--
-- Data for Name: email_confirmation; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.email_confirmation (id, date_created, user_account_id, email_address, date_confirmed) FROM stdin;
\.
COPY core.email_confirmation (id, date_created, user_account_id, email_address, date_confirmed) FROM '$$PATH$$/2554.dat';

--
-- Name: email_confirmation_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.email_confirmation_id_seq', 916, true);


--
-- Data for Name: email_share; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.email_share (id, date_sent, article_id, user_account_id, message) FROM stdin;
\.
COPY core.email_share (id, date_sent, article_id, user_account_id, message) FROM '$$PATH$$/2576.dat';

--
-- Name: email_share_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.email_share_id_seq', 71, true);


--
-- Data for Name: email_share_recipient; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.email_share_recipient (id, email_share_id, email_address, user_account_id, is_successful) FROM stdin;
\.
COPY core.email_share_recipient (id, email_share_id, email_address, user_account_id, is_successful) FROM '$$PATH$$/2578.dat';

--
-- Name: email_share_recipient_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.email_share_recipient_id_seq', 94, true);


--
-- Data for Name: page; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.page (id, article_id, number, word_count, readable_word_count, url) FROM stdin;
\.
COPY core.page (id, article_id, number, word_count, readable_word_count, url) FROM '$$PATH$$/2549.dat';

--
-- Name: page_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.page_id_seq', 127044, true);


--
-- Data for Name: password_reset_request; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.password_reset_request (id, date_created, user_account_id, email_address, date_completed) FROM stdin;
\.
COPY core.password_reset_request (id, date_created, user_account_id, email_address, date_completed) FROM '$$PATH$$/2558.dat';

--
-- Name: password_reset_request_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.password_reset_request_id_seq', 15, true);


--
-- Data for Name: source; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.source (id, name, url, hostname, slug, parser) FROM stdin;
\.
COPY core.source (id, name, url, hostname, slug, parser) FROM '$$PATH$$/2550.dat';

--
-- Name: source_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.source_id_seq', 28106, true);


--
-- Data for Name: source_rule; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.source_rule (id, hostname, path, priority, action) FROM stdin;
\.
COPY core.source_rule (id, hostname, path, priority, action) FROM '$$PATH$$/2553.dat';

--
-- Name: source_rule_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.source_rule_id_seq', 105, true);


--
-- Data for Name: star; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.star (user_account_id, article_id, date_starred) FROM stdin;
\.
COPY core.star (user_account_id, article_id, date_starred) FROM '$$PATH$$/2552.dat';

--
-- Data for Name: tag; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.tag (id, name) FROM stdin;
\.
COPY core.tag (id, name) FROM '$$PATH$$/2584.dat';

--
-- Name: tag_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.tag_id_seq', 110760, true);


--
-- Data for Name: time_zone; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.time_zone (id, name, display_name, territory, base_utc_offset) FROM stdin;
\.
COPY core.time_zone (id, name, display_name, territory, base_utc_offset) FROM '$$PATH$$/2555.dat';

--
-- Data for Name: user_account; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.user_account (id, name, email, password_hash, password_salt, receive_reply_email_notifications, receive_reply_desktop_notifications, last_new_reply_ack, last_new_reply_desktop_notification, date_created, role, receive_website_updates, receive_suggested_readings, time_zone_id) FROM stdin;
\.
COPY core.user_account (id, name, email, password_hash, password_salt, receive_reply_email_notifications, receive_reply_desktop_notifications, last_new_reply_ack, last_new_reply_desktop_notification, date_created, role, receive_website_updates, receive_suggested_readings, time_zone_id) FROM '$$PATH$$/2548.dat';

--
-- Name: user_account_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.user_account_id_seq', 519, true);


--
-- Data for Name: user_page; Type: TABLE DATA; Schema: core; Owner: postgres
--

COPY core.user_page (id, page_id, user_account_id, date_created, last_modified, read_state, words_read, date_completed) FROM stdin;
\.
COPY core.user_page (id, page_id, user_account_id, date_created, last_modified, read_state, words_read, date_completed) FROM '$$PATH$$/2551.dat';

--
-- Name: user_page_id_seq; Type: SEQUENCE SET; Schema: core; Owner: postgres
--

SELECT pg_catalog.setval('core.user_page_id_seq', 134796, true);


--
-- Data for Name: user_account; Type: TABLE DATA; Schema: id_migration; Owner: postgres
--

COPY id_migration.user_account (old_id, new_id) FROM stdin;
\.
COPY id_migration.user_account (old_id, new_id) FROM '$$PATH$$/2588.dat';

--
-- Name: article_author article_author_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.article_author
    ADD CONSTRAINT article_author_pkey PRIMARY KEY (article_id, author_id);


--
-- Name: article article_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.article
    ADD CONSTRAINT article_pkey PRIMARY KEY (id);


--
-- Name: article article_slug_key; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.article
    ADD CONSTRAINT article_slug_key UNIQUE (slug);


--
-- Name: article_tag article_tag_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.article_tag
    ADD CONSTRAINT article_tag_pkey PRIMARY KEY (article_id, tag_id);


--
-- Name: author author_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.author
    ADD CONSTRAINT author_pkey PRIMARY KEY (id);


--
-- Name: bulk_mailing bulk_mailing_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.bulk_mailing
    ADD CONSTRAINT bulk_mailing_pkey PRIMARY KEY (id);


--
-- Name: bulk_mailing_recipient bulk_mailing_recipient_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.bulk_mailing_recipient
    ADD CONSTRAINT bulk_mailing_recipient_pkey PRIMARY KEY (bulk_mailing_id, user_account_id);


--
-- Name: challenge_award challenge_award_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.challenge_award
    ADD CONSTRAINT challenge_award_pkey PRIMARY KEY (id);


--
-- Name: challenge challenge_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.challenge
    ADD CONSTRAINT challenge_pkey PRIMARY KEY (id);


--
-- Name: challenge_response challenge_response_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.challenge_response
    ADD CONSTRAINT challenge_response_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: email_bounce email_bounce_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_bounce
    ADD CONSTRAINT email_bounce_pkey PRIMARY KEY (id);


--
-- Name: email_confirmation email_confirmation_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_confirmation
    ADD CONSTRAINT email_confirmation_pkey PRIMARY KEY (id);


--
-- Name: email_share email_share_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_share
    ADD CONSTRAINT email_share_pkey PRIMARY KEY (id);


--
-- Name: email_share_recipient email_share_recipient_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_share_recipient
    ADD CONSTRAINT email_share_recipient_pkey PRIMARY KEY (id);


--
-- Name: page page_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.page
    ADD CONSTRAINT page_pkey PRIMARY KEY (id);


--
-- Name: password_reset_request password_reset_request_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.password_reset_request
    ADD CONSTRAINT password_reset_request_pkey PRIMARY KEY (id);


--
-- Name: source source_hostname_key; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.source
    ADD CONSTRAINT source_hostname_key UNIQUE (hostname);


--
-- Name: source source_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.source
    ADD CONSTRAINT source_pkey PRIMARY KEY (id);


--
-- Name: source_rule source_rule_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.source_rule
    ADD CONSTRAINT source_rule_pkey PRIMARY KEY (id);


--
-- Name: source source_slug_key; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.source
    ADD CONSTRAINT source_slug_key UNIQUE (slug);


--
-- Name: star star_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.star
    ADD CONSTRAINT star_pkey PRIMARY KEY (user_account_id, article_id);


--
-- Name: tag tag_name_key; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.tag
    ADD CONSTRAINT tag_name_key UNIQUE (name);


--
-- Name: tag tag_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.tag
    ADD CONSTRAINT tag_pkey PRIMARY KEY (id);


--
-- Name: time_zone time_zone_name_territory_key; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.time_zone
    ADD CONSTRAINT time_zone_name_territory_key UNIQUE (name, territory);


--
-- Name: time_zone time_zone_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.time_zone
    ADD CONSTRAINT time_zone_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.user_account
    ADD CONSTRAINT user_account_pkey PRIMARY KEY (id);


--
-- Name: user_page user_page_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.user_page
    ADD CONSTRAINT user_page_pkey PRIMARY KEY (id);


--
-- Name: challenge_contender_challenge_id_name_key; Type: INDEX; Schema: challenge_api; Owner: postgres
--

CREATE UNIQUE INDEX challenge_contender_challenge_id_name_key ON challenge_api.challenge_contender USING btree (challenge_id, name);


--
-- Name: page_article_id_idx; Type: INDEX; Schema: core; Owner: postgres
--

CREATE INDEX page_article_id_idx ON core.page USING btree (article_id);


--
-- Name: user_account_email_key; Type: INDEX; Schema: core; Owner: postgres
--

CREATE UNIQUE INDEX user_account_email_key ON core.user_account USING btree (lower((email)::text));


--
-- Name: user_account_name_key; Type: INDEX; Schema: core; Owner: postgres
--

CREATE UNIQUE INDEX user_account_name_key ON core.user_account USING btree (lower((name)::text));


--
-- Name: article _RETURN; Type: RULE; Schema: article_api; Owner: postgres
--

CREATE RULE "_RETURN" AS
    ON SELECT TO article_api.article DO INSTEAD  SELECT article.id,
    article.title,
    article.slug,
    article.source_id,
    source.name AS source,
    article.date_published,
    article.date_modified,
    article.section,
    article.description,
    article.aotd_timestamp,
    article.score,
    article_pages.urls[1] AS url,
    COALESCE(authors.names, '{}'::text[]) AS authors,
    COALESCE(tags.names, '{}'::text[]) AS tags,
    article_pages.word_count,
    article_pages.readable_word_count,
    article_pages.count AS page_count,
    COALESCE(comments.count, (0)::bigint) AS comment_count,
    comments.latest_date AS latest_comment_date,
    COALESCE(reads.count, (0)::bigint) AS read_count,
    reads.latest_date AS latest_read_date
   FROM ((((((core.article
     JOIN article_api.article_pages ON ((article_pages.article_id = article.id)))
     JOIN core.source ON ((source.id = article.source_id)))
     LEFT JOIN ( SELECT array_agg(author.name) AS names,
            article_author.article_id
           FROM (core.author
             JOIN core.article_author ON ((article_author.author_id = author.id)))
          GROUP BY article_author.article_id) authors ON ((authors.article_id = article.id)))
     LEFT JOIN ( SELECT array_agg(tag.name) AS names,
            article_tag.article_id
           FROM (core.tag
             JOIN core.article_tag ON ((article_tag.tag_id = tag.id)))
          GROUP BY article_tag.article_id) tags ON ((tags.article_id = article.id)))
     LEFT JOIN ( SELECT count(*) AS count,
            max(comment.date_created) AS latest_date,
            comment.article_id
           FROM core.comment
          GROUP BY comment.article_id) comments ON ((comments.article_id = article.id)))
     LEFT JOIN ( SELECT count(*) AS count,
            max(user_article_read.last_modified) AS latest_date,
            user_article_read.article_id
           FROM article_api.user_article_read
          GROUP BY user_article_read.article_id) reads ON ((reads.article_id = article.id)))
  GROUP BY article.id, source.id, article_pages.urls, article_pages.word_count, article_pages.readable_word_count, article_pages.count, authors.names, tags.names, comments.count, comments.latest_date, reads.count, reads.latest_date;


--
-- Name: challenge _RETURN; Type: RULE; Schema: challenge_api; Owner: postgres
--

CREATE RULE "_RETURN" AS
    ON SELECT TO challenge_api.challenge DO INSTEAD  SELECT challenge.id,
    challenge.name,
    challenge.start_date,
    challenge.end_date,
    challenge.award_limit,
    count(challenge_award.*) AS award_count
   FROM (core.challenge
     LEFT JOIN core.challenge_award ON ((challenge_award.challenge_id = challenge.id)))
  GROUP BY challenge.id;


--
-- Name: article_author article_author_article_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.article_author
    ADD CONSTRAINT article_author_article_id_fkey FOREIGN KEY (article_id) REFERENCES core.article(id);


--
-- Name: article_author article_author_author_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.article_author
    ADD CONSTRAINT article_author_author_id_fkey FOREIGN KEY (author_id) REFERENCES core.author(id);


--
-- Name: article article_source_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.article
    ADD CONSTRAINT article_source_id_fkey FOREIGN KEY (source_id) REFERENCES core.source(id);


--
-- Name: article_tag article_tag_article_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.article_tag
    ADD CONSTRAINT article_tag_article_id_fkey FOREIGN KEY (article_id) REFERENCES core.article(id);


--
-- Name: article_tag article_tag_tag_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.article_tag
    ADD CONSTRAINT article_tag_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES core.tag(id);


--
-- Name: bulk_mailing_recipient bulk_mailing_recipient_bulk_mailing_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.bulk_mailing_recipient
    ADD CONSTRAINT bulk_mailing_recipient_bulk_mailing_id_fkey FOREIGN KEY (bulk_mailing_id) REFERENCES core.bulk_mailing(id);


--
-- Name: bulk_mailing_recipient bulk_mailing_recipient_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.bulk_mailing_recipient
    ADD CONSTRAINT bulk_mailing_recipient_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES core.user_account(id);


--
-- Name: bulk_mailing bulk_mailing_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.bulk_mailing
    ADD CONSTRAINT bulk_mailing_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES core.user_account(id);


--
-- Name: challenge_award challenge_award_challenge_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.challenge_award
    ADD CONSTRAINT challenge_award_challenge_id_fkey FOREIGN KEY (challenge_id) REFERENCES core.challenge(id);


--
-- Name: challenge_award challenge_award_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.challenge_award
    ADD CONSTRAINT challenge_award_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES core.user_account(id);


--
-- Name: challenge_response challenge_response_challenge_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.challenge_response
    ADD CONSTRAINT challenge_response_challenge_id_fkey FOREIGN KEY (challenge_id) REFERENCES core.challenge(id);


--
-- Name: challenge_response challenge_response_time_zone_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.challenge_response
    ADD CONSTRAINT challenge_response_time_zone_id_fkey FOREIGN KEY (time_zone_id) REFERENCES core.time_zone(id);


--
-- Name: challenge_response challenge_response_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.challenge_response
    ADD CONSTRAINT challenge_response_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES core.user_account(id);


--
-- Name: comment comment_article_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.comment
    ADD CONSTRAINT comment_article_id_fkey FOREIGN KEY (article_id) REFERENCES core.article(id);


--
-- Name: comment comment_parent_comment_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.comment
    ADD CONSTRAINT comment_parent_comment_id_fkey FOREIGN KEY (parent_comment_id) REFERENCES core.comment(id);


--
-- Name: comment comment_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.comment
    ADD CONSTRAINT comment_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES core.user_account(id);


--
-- Name: email_bounce email_bounce_bulk_mailing_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_bounce
    ADD CONSTRAINT email_bounce_bulk_mailing_id_fkey FOREIGN KEY (bulk_mailing_id) REFERENCES core.bulk_mailing(id);


--
-- Name: email_confirmation email_confirmation_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_confirmation
    ADD CONSTRAINT email_confirmation_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES core.user_account(id);


--
-- Name: email_share email_share_article_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_share
    ADD CONSTRAINT email_share_article_id_fkey FOREIGN KEY (article_id) REFERENCES core.article(id);


--
-- Name: email_share_recipient email_share_recipient_email_share_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_share_recipient
    ADD CONSTRAINT email_share_recipient_email_share_id_fkey FOREIGN KEY (email_share_id) REFERENCES core.email_share(id);


--
-- Name: email_share_recipient email_share_recipient_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_share_recipient
    ADD CONSTRAINT email_share_recipient_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES core.user_account(id);


--
-- Name: email_share email_share_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.email_share
    ADD CONSTRAINT email_share_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES core.user_account(id);


--
-- Name: page page_article_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.page
    ADD CONSTRAINT page_article_id_fkey FOREIGN KEY (article_id) REFERENCES core.article(id);


--
-- Name: password_reset_request password_reset_request_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.password_reset_request
    ADD CONSTRAINT password_reset_request_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES core.user_account(id);


--
-- Name: star star_article_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.star
    ADD CONSTRAINT star_article_id_fkey FOREIGN KEY (article_id) REFERENCES core.article(id);


--
-- Name: star star_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.star
    ADD CONSTRAINT star_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES core.user_account(id);


--
-- Name: user_account user_account_time_zone_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.user_account
    ADD CONSTRAINT user_account_time_zone_id_fkey FOREIGN KEY (time_zone_id) REFERENCES core.time_zone(id);


--
-- Name: user_page user_page_page_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.user_page
    ADD CONSTRAINT user_page_page_id_fkey FOREIGN KEY (page_id) REFERENCES core.page(id);


--
-- Name: user_page user_page_user_account_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.user_page
    ADD CONSTRAINT user_page_user_account_id_fkey FOREIGN KEY (user_account_id) REFERENCES core.user_account(id);


--
-- Name: challenge_contender; Type: MATERIALIZED VIEW DATA; Schema: challenge_api; Owner: postgres
--

REFRESH MATERIALIZED VIEW challenge_api.challenge_contender;


--
-- PostgreSQL database dump complete
--

